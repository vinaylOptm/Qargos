/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_manager_canproc.c					   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "timers.h"
#include "fsl_debug_console.h"
#include "clock_config.h"
#include "fsl_flexcan.h"
#include "fsl_gpt.h"

#include "cluster_common.h"
#include "cluster_controller_hal.h"
#include "cluster_controller_hal_can.h"
#include "cluster_controller_manager_canproc.h"
#include "cluster_controller_manager_systeminfo.h"
#include "cluster_controller_manager_rtcproc.h"
#include "cluster_controller_manager_switchproc.h"
#include "cluster_controller_manager_udsproc.h"
#include "cluster_controller_manager_faultcode.h"

/*----------------------------------------------------------------------------*
 * Macro ,Structure and Enum definitions                        			  *
 *-----------------------------------------------------------------------------*/
#define CAN_MAX_QUEUE_MSG_COUNT				150
#define CAN_MSG_BUFFER_SIZE					sizeof(sCanMsg_t)
#define MSG_RECEIVE_INIT_WAIT				2000
#define READY_STATE_WAIT_TIME               3000
#define MSG_RECEIVE_ERROR_WAIT              10000
#define MSG_RECEIVE_DEFAULT_WAIT			60000
#define MSG_SEND_DEFAULT_WAIT				5000
#define CAN_SEND_MBID						25
#define SPEED_CACHE_SIZE					2

#define FLASH_MODE                          0xF1
#define RTC_SET_TIME                        0xF2
#define FACTORY_RESET                    	0xF3
#define BACKLIGHT_SET                       0xF4
#define CANPROC_GPTIMER                 	GPT1
#define HARDWARE_STATUS                     0xF5
#define READ_SWHW_VERSION                   0xF6
#define PRODUCT_SWHW_VERSION                0xF7
#define VINFO_WRITE_START           		0xF8
#define VINFO_WRITE_CONTINUE				0xF9
#define VINFO_WRITE_END     			    0xFA
#define VINFO_READ     			            0xFB
#define VINFO_READ_CONTINUE  				0xFC
#define VINFO_READ_END       				0xFD
#define SET_ODO                             0xFE

#define SLN_NUMBER                           0x01
#define VIN                                 0x02
#define DATE                                0x04

#define CANPROC_GPTIMER                     GPT1

#define DUR_MAX_QUEUE_COUNT					10
#define DUR_BUFFER_SIZE						256
#define DUR_QUEUE_BUFFER_SIZE 				DUR_BUFFER_SIZE + 16
#define SECONDS_PER_DAY 86400

#define MAX_ERROR_ID						32
#define ERROR_BUF_LEN						128
#define FAULT_MAX_QUEUE_COUNT				10
#define FAULT_BUFFER_SIZE					256

#define FAULT_QUEUE_BUFFER_SIZE 			(sizeof(sFaultMsg_t) + 16)

typedef struct
{
	bool	        	bIsOdoCached;
	bool				bCanError;
	bool                bIsResetDist;
	bool                bIgnition;
	bool				bGunlock;
	uint32_t			iErrorCode;
	int32_t     		iIsInitialised;
	uint8_t             iCurIgnStatus;
	uint8_t             iCurDriveStatus;
	uint8_t             sInfoCacheData[32];
	uint32_t			iChargeStatusCount;
	uint32_t            iSOCUpdateCount;
	uint32_t  			iCurTime;
	uint32_t   			iPrevTime;
	uint32_t	        iCurIndex;
	uint32_t            iChargeTime;
	uint32_t			iChargeStatus;
	uint32_t			iSpeed[SPEED_CACHE_SIZE];
	uint64_t			iTimeOffset[SPEED_CACHE_SIZE];
	uint8_t				iPrevTimeMins;
	uint8_t				iPrevTimeHrs;
	uint32_t 			iCurSoc;
	uint32_t 			iCurRange;
	uint32_t 			iCurTrip;
	uint64_t			iCurTripA;
	uint64_t			iCurTripB;
	uint64_t 			iCurOdo;
	uint64_t 			iCurOdoKms;
	uint64_t 			iCurOdoA;
	uint64_t 			iCurOdoB;
	uint64_t 			iInitialOdo;
	uint64_t 			iInitialOdoA;
	uint64_t 			iInitialOdoB;
	uint64_t 			iPrevOdo;
	uint64_t 			iPrevOdoA;
	uint64_t 			iPrevOdoB;
	uint64_t			ipOdo;
	uint32_t            iHmiDropCount;
	TickType_t          tLastFlashWrite;
	TickType_t			dt;
	bool                bIsInfoDirty;
	uint32_t			iCustomOdo;
	uint64_t 			iCurOdoDiff;
	QueueHandle_t		qCmdMsg;
	QueueHandle_t   	qRxMsg;
	QueueHandle_t   	qHmiMsg;
	QueueHandle_t   	qUdsRxMsg;
	TaskHandle_t 		hRxThread;
	TaskHandle_t 		hCmdThread;
	sMotorInfo_t 		sMotor;
	sMotorInfo_t 		sCurMotor;
	sBatteryInfo_t 		sBattery;
	sBatteryInfo_t 		sCurBattery;
	sDriveMode_t  		sDriveMode;
	sChargeInfo_t     	sCharge;
	sHwInputs_t         sHwStatus;
	sDeviceInfo_t       sSysInfo;
	sDeviceInfo_t       sSysInfoCache;
	sTimeInfo_t			sTime;
	sChargeAlert_t		sChargeAlert;
	sFault_t			sFault;
	sVFaultInfo_t		vFaultInfo;
	sFaultMsg_t			sQueueFault;
//Customer specific
	sStatus0_t        	sStatus0;
	sStatus0_t        	sCurrStatus0;
	sStatus1_t        	sStatus1;
	sStatus1_t        	sCurrStatus1;
	QueueHandle_t   	qDurMsg;
	QueueHandle_t   	qUpdateMsg;
	TaskHandle_t 		hDurThread;
	TaskHandle_t 		hUpdateThread;
	QueueHandle_t   	qIDMsg;
	TaskHandle_t 		hIDThread;
	TaskHandle_t 		hErThread;
	QueueHandle_t   	qErMsg;
}CanProc_t;

/*----------------------------------------------------------------------------*
 * Static and global variaCan definition	                         		  *
 *----------------------------------------------------------------------------*/
static CanProc_t hCanProc = {0};
/*----------------------------------------------------------------------------*
 * Local function definition	                         				      *
 *----------------------------------------------------------------------------*/
static void CanProc_CleanUp(void* arg);
static void CanProc_TimerConfigure(void);
static void CanProc_DataHandler(void *arg);
static int32_t CanProc_ProductionReset(void);
static uint32_t CanProc_GetCurrentTimestamp(void);
static void CanProc_SendMotorInfo(CanProc_t* pHan);
static void CanProc_Send_DummyData(CanProc_t* pHan);
static void CanProc_SendBatteryInfo(CanProc_t* pHan);
static int32_t CanProc_GetCachedData(CanProc_t* pHan);
static void CanProc_TripReset(CanProc_t* pHan,uint8_t iSelTrip);
static int32_t CanProc_SetOdoInfo(CanProc_t* pHan,uint32_t iOdo);
static void CanProc_UpdateSystemInfo(CanProc_t* pHan, uint32_t iMode);
static void CanProc_UpdateSpeedInfo(CanProc_t* pHan, uint32_t iMode);
static int CanProc_ResetDistanceParams(CanProc_t* pHan);
static int CanProc_CalculateSpeedParams(CanProc_t* pHan);
static void CanProc_UpdateInfo(CanProc_t* pHan, uint64_t iOdoDiff,uint32_t iMode );
static int CanProc_UpdateDistance(CanProc_t* pHan);
static int  CanProc_ComposeRespCommnd(uint8_t * pCmd,void * vpData);
static void CanProc_DataParse(CanProc_t * pHan, flexcan_frame_t* pMsg);
static int  CanProc_SendCommand(int32_t iCanId,uint32_t iLen,uint8_t *pdata,uint8_t mbIdx,uint8_t iFormat);
static void CanProc_SendTextMsgInfo(CanProc_t* pHan, eAlertId_t iId, uint32_t iCode);
static void CanProc_UpdateBatteryInfo(CanProc_t * pHan);
static void CanProc_SendChargingInfo(CanProc_t* pHan);
static void CanProcStatus_UpdateChargeInfo(CanProc_t* pHan);
static void CanProc_UIUpdateHandler(void *args);

//Customer specific
static void CanProc_ParseTime(CanProc_t* pHan, flexcan_frame_t* pFrame);
static void CanProc_SendTimeDateInfo(CanProc_t* pHan);
static void CanProc_UpdateDriveMode(CanProc_t* pHan ,flexcan_frame_t* pFrame);
static void CanProc_SendDriveModeInfo(CanProc_t* pHan);
static void CanProc_UpdateStatus0(CanProc_t* pHan ,flexcan_frame_t* pFrame);
static void CanProc_UpdateStatus1(CanProc_t* pHan ,flexcan_frame_t* pFrame);
static void CanProc_UpdateStatus0_Info(CanProc_t* pHan);
static void CanProc_UpdateStatus1_Info(CanProc_t* pHan);
static void CanProc_SendStatus0_Info(CanProc_t* pHan);
static void CanProc_SendStatus1_Info(CanProc_t* pHan);

//Fault/Error Msg
static void CanProc_Process_FaultMsgHandler(void *pvParameters);
static void CanProc_SendFaultInfo(CanProc_t* pHan);
static void CanProc_Process_TextMsgFaults(CanProc_t* pHan,flexcan_frame_t* pFrame);
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_CanProc_Init    	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_Init(QueueHandle_t hAppQueueId)
{
	int32_t iRval = BCU_OK;
	BaseType_t iTaskRetval = 0;
	if(hCanProc.iIsInitialised == 0)
	{
		memset(&hCanProc, 0 ,sizeof(hCanProc));

		hCanProc.qHmiMsg = hAppQueueId;

		hCanProc.qRxMsg = xQueueCreate( CAN_MAX_QUEUE_MSG_COUNT,CAN_MSG_BUFFER_SIZE);

		hCanProc.qCmdMsg = xQueueCreate(1,8);

		if((hCanProc.qRxMsg != 0) && (hCanProc.qCmdMsg != 0))
		{
			uint16_t iStackSize =0;

			Cluster_Controller_Hal_ConfigGetStackSize(&iStackSize);

			iTaskRetval = xTaskCreate(CanProc_DataHandler,
									"CANP",
									iStackSize*2,
									&hCanProc,
									CLUSTER_TASK_PRIORITY_DATA,
									&hCanProc.hRxThread);
			if (iTaskRetval == pdPASS)
			{
				hCanProc.qUpdateMsg = xQueueCreate(DUR_MAX_QUEUE_COUNT, DUR_QUEUE_BUFFER_SIZE);
				iTaskRetval = xTaskCreate(CanProc_UIUpdateHandler,
										"UPDATE",
										iStackSize*2,
										&hCanProc,
										CLUSTER_TASK_PRIORITY_BACKGROUND,
										&hCanProc.hUpdateThread);
				if (iTaskRetval == pdPASS)
				{
					hCanProc.iIsInitialised = 1;
					CanProc_TimerConfigure();
				}
				else
				{
					iRval = BCU_NOK;
					Cluster_Controller_Manager_CanProc_DeInit();
					PRINTF("\r\nError: CanProc_UIUpdateHandler: Thread create failed \r\n");
				}
			}
			else
			{
				iRval = BCU_NOK;
				Cluster_Controller_Manager_CanProc_DeInit();
				PRINTF("\r\nError: CanProc_DataHandler: Thread create failed \r\n");
			}
		}
		else
		{
			iRval = BCU_NOK;
			PRINTF("\r\nError:CanProc: xQueueCreate  failed \r\n");
		}

		hCanProc.qErMsg = xQueueCreate(FAULT_MAX_QUEUE_COUNT, FAULT_QUEUE_BUFFER_SIZE);
		if(hCanProc.qErMsg != 0)
		{
			xTaskCreate(CanProc_Process_FaultMsgHandler,
						"ERMSG",
						512,
						&hCanProc,
						(configMAX_PRIORITIES - 2),
						&hCanProc.hErThread);
		}
		else
		{
			PRINTF("\r\nError:ERRMSG: xQueueCreate  failed \r\n");
		}
	}

	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_CanProc_DeInit	 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
void Cluster_Controller_Manager_CanProc_DeInit(void)
{
	if(hCanProc.iIsInitialised)
	{
		vTaskSuspend(hCanProc.hRxThread);
		CanProc_CleanUp(NULL);
	}
	memset(&hCanProc, 0, sizeof(CanProc_t));
}
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_CanProc_Stop		 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_Start(void)
{
	int32_t iRval = BCU_NOK;

	if((hCanProc.iIsInitialised) && (hCanProc.qRxMsg != NULL))
	{
		iRval = Cluster_Controller_Hal_SetReceiveQueueHandle(eModule_Can ,
															 hCanProc.qRxMsg);
	}
	return  iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_CanProc_Stop		 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_Stop(void)
{
	return 0;
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Manager_CanProc_SendMessage	 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_SendMessage(sCanMessage_t *pMsg,uint8_t mbIdx)
{
	return Cluster_Controller_Hal_CanSendMessage(pMsg,mbIdx);
}
/*------------------------------------------------------------------------------*
 * Function	    :  		Cluster_Controller_Manager_CanProc_Reset				*
 * Params	    :		Void			                                      	*
 * Return value	:		Void		                                            *
 * Description	:																*
 *                                                                              *
 *------------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_Reset(void)
{
	int32_t iRval = BCU_OK;
	if(hCanProc.iIsInitialised)
	{
		CanProc_Send_DummyData(&hCanProc);
	}
	return iRval;
}
/*------------------------------------------------------------------------------*
 * Function	    :  		Cluster_Controller_Manager_CanProc_IngStatus			*
 * Params	    :		Void			                                      	*
 * Return value	:		Void		                                            *
 * Description	:																*
 *                                                                              *
 *------------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_IgnitionStatus(uint8_t iStatus)
{
	int32_t iRval = BCU_OK;

	if (hCanProc.iIsInitialised)
	{
		if (hCanProc.iCurIgnStatus != iStatus)
		{
#if 0
			uint64_t iOdoDiff = (uint64_t)((hCanProc.iCurOdo - hCanProc.iPrevOdo)/100ULL);

			if ((iStatus == 0) && (hCanProc.iCurIgnStatus == 1) && (iOdoDiff > 300))
			{
				//CanProc_UpdateSystemInfo(&hCanProc,eSpeedInfo);
				PRINTF("\r\n Ignition off: iOdoDiff : %d \r\n",iOdoDiff);
			}
#endif
			hCanProc.iCurIgnStatus = iStatus;
		}
	}
	return iRval;
}
/*------------------------------------------------------------------------------*
 * Function	    :  		Cluster_Controller_Manager_CanProc_ResetTrip			*
 * Params	    :		Void			                                      	*
 * Return value	:		Void		                                            *
 * Description	:																*
 *                                                                              *
 *------------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_ResetTrip(uint8_t iSelTrip)
{
	int32_t iRval = BCU_OK;
	if(hCanProc.iIsInitialised)
	{
		CanProc_TripReset(&hCanProc,iSelTrip);
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ProductionReset		    		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_ProductionReset(void)
{
	return CanProc_ProductionReset();
}
/*----------------------------------------------------------------------------*
 * Function	      	:	Cluster_Controller_Manager_CanProc_SetUdsQueueHan				          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_SetUdsQueueHan(QueueHandle_t qRxMsg)
{
	int32_t iRval = BCU_OK;
	if (hCanProc.iIsInitialised)
	{
		hCanProc.qUdsRxMsg = qRxMsg;
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	Cluster_Controller_Manager_CanProc_GetCanFrame    	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_GetCanFrame(uint8_t * pFrame, uint8_t iFrameId)
{
	int32_t iRtval = BCU_NOK;
	(void)(pFrame);
	(void)(iFrameId);
//	memcpy(pFrame,&(hCanProc.sCanFrame[iFrameId-1][0]), sizeof(hCanProc.sCanFrame[iFrameId-1]));

	return iRtval;
}
/*------------------------------------------------------------------------------*
 * Function	    :  		Cluster_Controller_Manager_CanProc_GetMotorInfo			*
 * Params	    :		Void			                                      	*
 * Return value	:				                                            *
 * Description	:																*
 *                                                                              *
 *------------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_GetMotorInfo(sMotorInfo_t *pMotor,sBatteryInfo_t *pBattery)
{
	int32_t iRval = BCU_OK;
	if(hCanProc.iIsInitialised)
	{
		memcpy(pMotor,&hCanProc.sMotor,sizeof(sMotorInfo_t));
		memcpy(pBattery,&hCanProc.sBattery,sizeof(sBatteryInfo_t));
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_TimerConfigure				          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_TimerConfigure()
{
	gpt_config_t gptConfig = {
								.clockSource = kGPT_ClockSource_Periph,
								.divider = 1,
								.enableRunInStop = false,
								.enableMode =true
							};

	GPT_Init(CANPROC_GPTIMER, &gptConfig);
	GPT_StopTimer(CANPROC_GPTIMER);
	GPT_StartTimer(CANPROC_GPTIMER); /*start timer*/
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_DataHandler						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_DataHandler(void *arg)
{
	int32_t iDelay = READY_STATE_WAIT_TIME;
	int32_t iRval = BCU_NOK;
	CanProc_t *  pHan = (CanProc_t *)(arg);

	int iCount  = 0;
	sCanMsg_t sMsg;

	CanProc_ResetDistanceParams(pHan);

	xQueueReceive(pHan->qRxMsg,(void *)(&sMsg),(TickType_t)(iDelay));
	iRval  = Cluster_Controller_Hal_CanEnable();
	iDelay = MSG_RECEIVE_INIT_WAIT;

	if(iRval == BCU_OK)
	{
		while (1)
		{
			memset(&sMsg, 0, sizeof(sCanMsg_t));
			if(pdPASS == xQueueReceive(pHan->qRxMsg,(void *)(&sMsg),(TickType_t)(iDelay)))
			{
				if(sMsg.iEventId == 0)
				{
					if( pHan->bCanError == 1)
					{
						CanProc_SendTextMsgInfo(pHan,eAlert_CAN,eCAN_Working);
						pHan->bCanError = 0;
						CanProc_ResetDistanceParams(pHan);
					}

					iCount = 0;

					CanProc_DataParse(pHan,&(sMsg.sRxFrame));

					if(pHan->bIsOdoCached == 0)
					{
						CanProc_Send_DummyData(pHan);
					}

					iDelay = MSG_RECEIVE_DEFAULT_WAIT;
				}
				else
				{
					Cluster_Controller_Hal_CanReset(false);
					iDelay = MSG_RECEIVE_ERROR_WAIT;
					if(pHan->bCanError == 0)
					{
						pHan->iCurTime = 0;
						pHan->iPrevTime = 0;
						PRINTF("\r\nCAN ERROR :ID = %d, Code= %d\r\n",sMsg.iErrId,sMsg.iEventId);
						CanProc_SendTextMsgInfo(pHan,eAlert_CAN,eCAN_Error);
					}
					pHan->bCanError = 1;
				}
			}
			else
			{
				if(iDelay != MSG_RECEIVE_ERROR_WAIT)
				{
					if(iCount == 0)
					{
						PRINTF("\r\nCAN : HMI Update with reset value \r\n");
						pHan->sMotor.iRpm = 0;
						pHan->sBattery.iSoc = 0;
						pHan->sCurMotor.iRpm = 0;
						pHan->sCurBattery.iSoc = 0;
						CanProc_Send_DummyData(pHan);
						CanProc_SendBatteryInfo(pHan);
						pHan->bIsOdoCached = 1;
						iCount = 1;
					}
					CanProc_SendTextMsgInfo(pHan,eAlert_CAN,eCAN_NoData);
					pHan->bCanError = 1;
					//CanProc_FlushSystemInfo(pHan,1);
				}
				iDelay = MSG_RECEIVE_DEFAULT_WAIT;
			}
		}
	}
	else
	{
		CanProc_SendTextMsgInfo(pHan,eAlert_CAN,eCAN_NoData);
		pHan->bCanError = 1;

		PRINTF("\r\n Error: CanProc_DataHandler : Cluster_Controller_Hal_CanEnable Failed\r\n");
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_CleanUp							          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_CleanUp(void* arg)
{
    (void)(arg);
	if(hCanProc.qRxMsg != 0)
	{
		vQueueDelete(hCanProc.qRxMsg);
	}
	if(hCanProc.qCmdMsg != 0)
	{
		vQueueDelete(hCanProc.qCmdMsg);
	}
	if(hCanProc.qDurMsg != 0)
	{
		vQueueDelete(hCanProc.qDurMsg);
	}
	if(hCanProc.qUpdateMsg != 0)
	{
		vQueueDelete(hCanProc.qUpdateMsg);
	}
	if(hCanProc.qIDMsg != 0)
	{
		vQueueDelete(hCanProc.qIDMsg);
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_DataParse						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_DataParse(CanProc_t * pHan,flexcan_frame_t* pFrame)
{
	int iRetVal = BCU_OK;
	int iCanId = 0;
	int iLen   = 0;
	if (pFrame != NULL)
	{
		if(pFrame->format == kFLEXCAN_FrameFormatStandard)
		{
			iCanId = pFrame->id >> CAN_ID_STD_SHIFT;
		}
		else
		{
			iCanId = pFrame->id >> CAN_ID_EXT_SHIFT;
		}

		iLen   = pFrame->length;

		switch(iCanId)
		{
			case eCANID_Frame1:
			{
				if(iLen == 8)
				{
					pHan->sCharge.bIgnition = ((pFrame->dataByte3) & 0x01)? true: false;	//Ignition
					pHan->sCharge.bChargeInfo = ((pFrame->dataByte6) & 0x80)? true: false;

					if(pHan->sCharge.bChargeInfo)
					{
						pHan->sCharge.iStatus = eChargestate_Complete;
					}
					else
					{
						pHan->sCharge.iStatus 	= ((pFrame->dataByte3) & 0x02)? eChargestate_Charging : eChargestate_Idle;//Charging/discharge
					}

					pHan->sCharge.bGunlock  = ((pFrame->dataByte7) & 0x01)? true: false;	//Charging Gun Connected
					pHan->sCharge.bMotorOn  = ((pFrame->dataByte7) & 0x02)? true: false;	//Motor_ON
					pHan->sCharge.iMsgState = (uint8_t)(((uint8_t)pHan->sCharge.bGunlock << 1) |
														((uint8_t)pHan->sCharge.bIgnition));

#if 0
					pHan->sCharge.bGunlock  = ((pFrame->dataByte7) & 0x01)? eChargestate_Connected : eChargestate_Idle;	//Charging Gun Connected
					pHan->sCharge.iStatus 	= ((pFrame->dataByte3) & 0x02)? eChargestate_Charging : eChargestate_Idle;//Charging/discharge
					pHan->sCharge.bChargeInfo = ((pFrame->dataByte6) & 0x80)? eChargestate_Complete : eChargestate_Idle;	//Charge Complete
#endif

					pHan->sStatus0.iService = ((pFrame->dataByte3) & 0x30);					//Service Remainder
					if(pHan->sStatus0.iService > 0)
					{
						pHan->sStatus0.iService = 1;
					}

					pHan->sTime.bPM  = ((pFrame->dataByte6) & 0x01)? true: false;			//am/pm

					CanProc_SendChargingInfo(pHan);
					CanProc_Process_TextMsgFaults(pHan,pFrame);
					CanProc_UpdateDriveMode(pHan,pFrame);
					CanProc_ParseTime(pHan, pFrame);
					CanProc_UpdateStatus0(pHan,pFrame);
				}
			}
			break;
			case eCANID_Frame2:
			{
				if(iLen == 8)
				{
					if(pHan->bIsOdoCached == 0)
					{
						iRetVal = CanProc_GetCachedData(pHan);
						if(iRetVal == BCU_OK)
						{
							pHan->bIsOdoCached = 1;
						}
					}

					uint32_t iOdo = (uint32_t)((pFrame->dataByte3 << 24) | (pFrame->dataByte2 << 16) |
					                           (pFrame->dataByte1 << 8)  | (pFrame->dataByte0));

					pHan->ipOdo = pHan->iPrevOdo;

					if (iOdo > pHan->ipOdo)
					{
						pHan->iCurOdoKms = iOdo;		  //in Kms
					    pHan->iCurOdo = iOdo * 1000ULL;   // Convert km -> mts

					    pHan->sMotor.iOdo = (uint32_t)(pHan->iCurOdo);   // in meters

					    if (pHan->sMotor.iOdo > 99999999U)
					    {
					        pHan->sMotor.iOdo = 0;
					    }
					}

					pHan->sMotor.iSpeed   = (uint32_t)(pFrame->dataByte5);
//					if(pHan->sMotor.iSpeed  > 80)
//					{
//						pHan->sMotor.iSpeed  = 80;
//					}

					CanProc_CalculateSpeedParams(pHan);
				}
			}
			break;
			case eCANID_Frame3:
			{
				if(iLen == 8)
				{
					pHan->sBattery.iRange = (uint32_t)((pFrame->dataByte3 << 8)  | (pFrame->dataByte2));
					if(pHan->sBattery.iRange >= 999)
					{
						pHan->sBattery.iRange = 999;
					}

					pHan->sBattery.iSoc  = (uint32_t)(pFrame->dataByte4);
					if(pHan->sBattery.iSoc >= 100)
					{
						pHan->sBattery.iSoc = 100;
					}

					CanProc_UpdateStatus1(pHan,pFrame);
					CanProc_SendBatteryInfo(pHan);
				}
			}
			break;
			case eCANID_Internal:
			{
				if(iLen == 8)
				{
					switch(pFrame->dataByte0)
					{
						case FLASH_MODE:
						{
							Cluster_Controller_Hal_FirmwareDownload_Init();
						}
						break;
						case RTC_SET_TIME:
						{
							sTimeInfo_t sRTCInfo = {0};

							sRTCInfo.iSecond = pFrame->dataByte1;
							sRTCInfo.iMinute = pFrame->dataByte2;
							sRTCInfo.iHour = pFrame->dataByte3;
							sRTCInfo.iDay = pFrame->dataByte4;
							sRTCInfo.iMonth = pFrame->dataByte5;
							sRTCInfo.iYear = pFrame->dataByte6;

							Cluster_Controller_Manager_RtcProc_CheckForValidData(&sRTCInfo);

							PRINTF("\r\n The RTC frame: [%x %x %x %x %x %x]",sRTCInfo.iSecond,sRTCInfo.iMinute,sRTCInfo.iHour,sRTCInfo.iDay,sRTCInfo.iMonth,sRTCInfo.iYear);

							Cluster_Controller_Hal_RtcSetDateTime(&sRTCInfo);
						}
						break;
						case FACTORY_RESET:
						{
							int32_t iRtval = BCU_NOK;

							iRtval = CanProc_ProductionReset();
							PRINTF("\r\n CanProc_ProductionReset \r\n");
							if(iRtval == BCU_OK)
							{
								pHan->sMotor.iTripA = 0;
								pHan->sMotor.iTripB = 0;
								pHan->sMotor.iOdo  = 0;
								pHan->iInitialOdo  = 0;
								pHan->iInitialOdoA  = 0;
								pHan->iInitialOdoB  = 0;
								pHan->iPrevOdo 	   = 0;
								pHan->iPrevOdoA 	   = 0;
								pHan->iPrevOdoB 	   = 0;
								pHan->iCurOdo 	   = 0;
								pHan->iCurOdoA 	   = 0;
								pHan->iCurOdoB 	   = 0;
								pHan->iCurTripA     = 0;
								pHan->iCurTripB     = 0;

								CanProc_ResetDistanceParams(pHan);
								CanProc_SendMotorInfo(pHan);
								PRINTF("\r\nThe Production Reset successful\r\n");
							}
						}
						break;
						case BACKLIGHT_SET:
						{
#if ENABLE_PWM_CONTROL
							uint32_t iRval = BCU_NOK;
							sClusterInfo_t sUpdateinfo = {0};

							sUpdateinfo.iBrightness = pFrame->dataByte1;

							iRval = Cluster_Controller_UpdateSystemInfo(&sUpdateinfo, eBrightnessInfo);
							if(iRval == BCU_OK)
							{
								Cluster_Controller_Hal_BacklightSetBrightness(sUpdateinfo.iBrightness);
							}
#endif
						}
						break;
						case HARDWARE_STATUS:
						{
							int32_t iRval = BCU_NOK;
							uint8_t sData[8] = {0};
							iRval = Cluster_Controller_SwitchProc_GetHwStatus(&(pHan->sHwStatus));
							if(iRval == BCU_OK)
							{
								sData[0] = (uint8_t)((( pHan->sHwStatus.bInput8 & 0x01) << 7) | (( pHan->sHwStatus.bInput7 & 0x01) << 6)
													| ((pHan->sHwStatus.bInput6 & 0x01) << 5) | ((pHan->sHwStatus.bInput5 & 0x01) << 4)
													| ((pHan->sHwStatus.bInput4 & 0x01) << 3) | ((pHan->sHwStatus.bInput3 & 0x01) << 2)
													| ((pHan->sHwStatus.bInput2 & 0x01) << 1) | (pHan->sHwStatus.bInput1 & 0x01));
								sData[1] = (uint8_t)(((pHan->sHwStatus.bInput10 & 0x01) << 1) | (pHan->sHwStatus.bInput9 & 0x01));
								iRval = CanProc_SendCommand(eCANID_Internal,8,&sData[0],15,0);
								if(iRval != BCU_OK)
								{
									PRINTF("\r\nError: CAN_PROC HARDWARE_STATUS CAN Send failed\r\n");
								}
							}
						}
						break;
						case READ_SWHW_VERSION:
						{
							int32_t iRval = BCU_NOK;
							uint8_t sData[8] = {0};
							uint32_t iSwVersion = 0;
							uint32_t iHwVersion = 0;
							Cluster_Controller_Hal_ConfigGetVersion(&iSwVersion, &iHwVersion);
							sData[0] = (uint8_t)iSwVersion;
							sData[1] = (uint8_t)iHwVersion;
							iRval = CanProc_SendCommand(eCANID_Internal,8,&sData[0],15,0);
							if(iRval != BCU_OK)
							{
								PRINTF("\r\nError: CAN_PROC READ_SWHW_VERSION CAN Send failed\r\n");
							}
						}
						break;
						case VINFO_WRITE_START:
						{
							Cluster_Controller_Manager_SystemInfo_GetVehicleSpecInfo(&(pHan->sSysInfoCache));
							pHan->sInfoCacheData[0] = pFrame->dataByte2;
							pHan->sInfoCacheData[1] = pFrame->dataByte3;
							pHan->sInfoCacheData[2] = pFrame->dataByte4;
							pHan->sInfoCacheData[3] = pFrame->dataByte5;
							pHan->sInfoCacheData[4] = pFrame->dataByte6;
							pHan->sInfoCacheData[5] = pFrame->dataByte7;
						}
						break;
						case VINFO_WRITE_CONTINUE:
						case VINFO_WRITE_END:
						{
							pHan->sInfoCacheData[6] = pFrame->dataByte2;
							pHan->sInfoCacheData[7] = pFrame->dataByte3;
							pHan->sInfoCacheData[8] = pFrame->dataByte4;
							pHan->sInfoCacheData[9] = pFrame->dataByte5;
							pHan->sInfoCacheData[10] = pFrame->dataByte6;
							pHan->sInfoCacheData[11] = pFrame->dataByte7;

							memcpy(&(pHan->sSysInfo),&(pHan->sSysInfoCache),sizeof(pHan->sSysInfo));

							if(pFrame->dataByte1 & SLN_NUMBER) //SlNum.
							{
								pHan->sSysInfo.iSlNum = ((uint32_t)pHan->sInfoCacheData[3] << 24) |
										((uint32_t)pHan->sInfoCacheData[2] << 16) |
										((uint32_t)pHan->sInfoCacheData[1] << 8)  |
										(uint32_t)pHan->sInfoCacheData[0];

								pHan->sSysInfoCache.iSlNum = pHan->sSysInfo.iSlNum;

								/*memcpy(pHan->sSysInfo.iSlNum,pHan->sInfoCacheData, sizeof(pHan->sSysInfo.iSlNum));
								memcpy(pHan->sSysInfoCache.iSlNum,pHan->sSysInfo.iSlNum, sizeof(pHan->sSysInfo.iSlNum));*/
							}
							else if(pFrame->dataByte1 & VIN) //VIN.
							{
								memcpy(pHan->sSysInfo.sVin, pHan->sInfoCacheData, sizeof(pHan->sSysInfo.sVin));

								memcpy(pHan->sSysInfoCache.sVin,pHan->sSysInfo.sVin, sizeof(pHan->sSysInfo.sVin));
							}

							Cluster_Controller_Manager_SystemInfo_SetVehicleSpecInfo(&(pHan->sSysInfo), eProductInfo);

							memset(&(pHan->sSysInfo), 0 , sizeof(pHan->sSysInfo));
							memset(pHan->sInfoCacheData, 0 , sizeof(pHan->sInfoCacheData));
						}
						break;
						case VINFO_READ:
						{
							uint8_t sData[8] = {0};

							sDeviceInfo_t sInfo = {0};

							Cluster_Controller_Manager_SystemInfo_GetVehicleSpecInfo(&sInfo);

							if((sInfo.iSlNum == 0xFFFFFFFF) && ((unsigned char) sInfo.sVin[0] == 0xFF))
							{
								DbgConsole_Printf("\r\nThe Device is New Set the Device details\r\n");
							}
							else
							{
								if((pFrame->dataByte1 & SLN_NUMBER) == SLN_NUMBER)
								{
									sData[0] = SLN_NUMBER;
									sData[1] = VINFO_READ_END;

									CanProc_ComposeRespCommnd(sData,&sInfo.iSlNum);
								}
								else if((pFrame->dataByte1 & VIN) == VIN)
								{
									sData[0] = VIN;
									sData[1] = VINFO_READ_CONTINUE;

									CanProc_ComposeRespCommnd(sData,sInfo.sVin);
								}
							}
						}
						break;
						case SET_ODO:
						{
							int32_t iRtval = BCU_NOK;
							uint32_t iOdo = (uint32_t)(((uint32_t)(pFrame->dataByte4) << 24) |
							    ((uint32_t)(pFrame->dataByte3) << 16) |
							    ((uint32_t)(pFrame->dataByte2) << 8) |
							    (uint32_t)(pFrame->dataByte1)
							);

							iRtval = CanProc_SetOdoInfo(pHan,iOdo);
							if(iRtval == BCU_OK)
							{
								PRINTF("\r\n Motor ODO: %d\r\n",pHan->sMotor.iOdo);
								pHan->iInitialOdo  		= (uint64_t)(pHan->sMotor.iOdo * 100ULL);
								pHan->iPrevOdo 	   		= (uint64_t)(pHan->iInitialOdo * 100ULL);
								pHan->iCurOdo 	   		= (uint64_t)(pHan->iInitialOdo * 100ULL);
								pHan->iInitialOdoA  	= (uint64_t)(pHan->iInitialOdo * 100ULL);
								pHan->iPrevOdoA 	   	= (uint64_t)(pHan->iInitialOdo * 100ULL);
								pHan->iCurOdoA 	   		= (uint64_t)(pHan->iInitialOdo * 100ULL);
								pHan->iInitialOdoB  	= (uint64_t)(pHan->iInitialOdo * 100ULL);
								pHan->iPrevOdoB 	   	= (uint64_t)(pHan->iInitialOdo * 100ULL);
								pHan->iCurOdoB 	   		= (uint64_t)(pHan->iInitialOdo * 100ULL);
								pHan->iCurTripA 		= (uint64_t)(pHan->sMotor.iTripA * 100ULL);
								pHan->iCurTripB 		= (uint64_t)(pHan->sMotor.iTripB * 100ULL);
								CanProc_SetOdoInfo(pHan,iOdo);
								CanProc_SendMotorInfo(pHan);

								CanProc_ResetDistanceParams(pHan);
								PRINTF("\r\n Motor iCurOdo: %lld\r\n",pHan->iCurOdo);
							CanProc_SendMotorInfo(pHan);
							}
						}
						break;
						default:
						break;
					}
				}
			}
			break;
#if(UDS_SERVICE_ENABLE == 1)
			case eCANID_UDSRx:
			{
				if (pHan->qUdsRxMsg != NULL)
				{
					if (xQueueSend(pHan->qUdsRxMsg, pFrame, (TickType_t)(MSG_SEND_DEFAULT_WAIT)) != pdPASS)
					{
						PRINTF("\r\nFailed to send message to the queue\r\n");
					}
				}
			}
			break;
#endif

			default:
				PRINTF("\r\n DataParse Default CAN ID: 0x%x\r\n",iCanId);
			break;
		}
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateBatteryInfo						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateBatteryInfo(CanProc_t * pHan)
{
	if((pHan->sCurBattery.iSoc != pHan->sBattery.iSoc) ||
	   (pHan->sCurBattery.iTemp != pHan->sBattery.iTemp)||
	   (pHan->sCurBattery.iRange != pHan->sBattery.iRange)||
	   (pHan->sCurBattery.iVoltage != pHan->sBattery.iVoltage)||
	   (pHan->iSOCUpdateCount > 100))
	{
		pHan->sCurBattery.iTemp = pHan->sBattery.iTemp;
		pHan->sCurBattery.iSoc = pHan->sBattery.iSoc;
		pHan->sCurBattery.iRange = pHan->sBattery.iRange;
		pHan->sCurBattery.iVoltage = pHan->sBattery.iVoltage;
		pHan->iSOCUpdateCount = 0;
		CanProc_SendBatteryInfo(pHan);
	}
	else
	{
		pHan->iSOCUpdateCount = pHan->iSOCUpdateCount+1;
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProcStatus_UpdateChargeInfo			          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProcStatus_UpdateChargeInfo(CanProc_t* pHan)
{
	if((pHan->iChargeStatus != pHan->sCharge.iStatus) ||
		(pHan->sCharge.iTime != pHan->iChargeTime) ||
		(pHan->sCharge.iStatus == eChargestate_Charging) ||
		(pHan->sCharge.iCount > 100))
	{
		pHan->iChargeStatus = pHan->sCharge.iStatus;
		pHan->sCharge.iTime = pHan->iChargeTime;

		CanProc_SendChargingInfo(pHan);
		pHan->sCharge.iCount = 0;
	}
	else
	{
		pHan->sCharge.iCount = pHan->sCharge.iCount + 1;
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendChargingInfo			          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendChargingInfo(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};

	if(pHan->qHmiMsg != NULL)
	{
		sMsg.iEventId 			= eEvent_Charge;
		memcpy((char *)sMsg.sData,(char*)(&(pHan->sCharge)),sizeof(sChargeInfo_t));
		if(xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(10U)) != pdPASS)
		{
			pHan->iHmiDropCount++;
		}
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateSpeedInfo				          		 *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateSpeedInfo(CanProc_t* pHan, uint32_t iMode)
{
	uint64_t iOdoDiff = (uint64_t)((pHan->iCurOdo - pHan->iPrevOdo)/100);

	if((pHan->sCurMotor.iSpeed != pHan->sMotor.iSpeed) ||
	   (pHan->sCurMotor.iRpm != pHan->sMotor.iRpm) ||
	   (pHan->sCurMotor.iPower != pHan->sMotor.iPower) ||
	   (pHan->sCurMotor.iRange != pHan->sMotor.iRange) ||
	   (pHan->sCurMotor.iTemp != pHan->sMotor.iTemp)||
	   ((iOdoDiff - pHan->iCurOdoDiff) > 100))
	{
		pHan->sCurMotor.iSpeed  = pHan->sMotor.iSpeed;
		pHan->sCurMotor.iRpm    = pHan->sMotor.iRpm;
		pHan->sCurMotor.iPower  = pHan->sMotor.iPower;
		pHan->sCurMotor.iRange  = pHan->sMotor.iRange;
	    pHan->sCurMotor.iTemp 	= pHan->sMotor.iTemp;
		pHan->iCurOdoDiff	 = iOdoDiff;

		CanProc_SendMotorInfo(pHan);
	}
	CanProc_UpdateInfo(pHan,iOdoDiff,iMode);
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateInfo					          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateInfo(CanProc_t* pHan, uint64_t iOdoDiff,uint32_t iMode)
{
	if ((pHan->sMotor.iSpeed < 5) && (iOdoDiff > 300))
	{
		CanProc_UpdateSystemInfo(pHan,iMode);
		pHan->iCurTime = 0;
		pHan->iPrevTime = 0;
	}
	else if((pHan->sMotor.iSpeed > 10) && (pHan->sMotor.iSpeed <= 30) && (iOdoDiff > 1000))
	{
		CanProc_UpdateSystemInfo(pHan,iMode);
	}
	else if((pHan->sMotor.iSpeed > 30) && (pHan->sMotor.iSpeed <= 50) && (iOdoDiff > 2000))
	{
		CanProc_UpdateSystemInfo(pHan,iMode);
	}
	else if((pHan->sMotor.iSpeed > 50) && (iOdoDiff > 3000))
	{
		CanProc_UpdateSystemInfo(pHan,iMode);
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ResetDistanceParams		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int CanProc_ResetDistanceParams(CanProc_t* pHan)
{
	int iRetVal = BCU_OK;

	if(pHan->bIsResetDist == 0)
	{
		for (int32_t i = 0; i < SPEED_CACHE_SIZE; i++)
		{
			pHan->iSpeed[i] = 0;
			pHan->iTimeOffset[i] = 0;
		}
		pHan->iCurIndex = 0;
		pHan->iCurTime = 0;
		pHan->bIsResetDist = 1;
	}

	return iRetVal;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_CalculateSpeedParams			          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int CanProc_CalculateSpeedParams(CanProc_t* pHan)
{
	int iRetVal = BCU_OK;

	iRetVal = CanProc_UpdateDistance(pHan);
	if(iRetVal == BCU_OK)
	{
		if(pHan->iCurOdo >= pHan->iInitialOdo)
		{
			if(pHan->iCurOdoA >= pHan->iInitialOdoA)
			{
				uint64_t iTripDiff  = (pHan->iCurOdoA - pHan->iInitialOdoA);
				pHan->sMotor.iTripA = (uint32_t)round((uint32_t)((pHan->iCurTripA + iTripDiff)/100ULL));// in meters
			}
			if(pHan->iCurOdoB >= pHan->iInitialOdoB)
			{
				uint64_t iTripDiff  = (pHan->iCurOdoB - pHan->iInitialOdoB);
				pHan->sMotor.iTripB = (uint32_t)round((uint32_t)((pHan->iCurTripB + iTripDiff)/100ULL));// in meters
			}
			iRetVal = BCU_OK;
		}
		else
		{
			PRINTF("\r\n ERROR: Initial Odo %d is greater than New Odo %d :\r\n",pHan->iInitialOdo,pHan->iCurOdo);
		}
	}
	return iRetVal;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateDistance		          	  			  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int CanProc_UpdateDistance(CanProc_t* pHan)
{
	int iRetVal = BCU_NOK;
	uint64_t iSum = 0;
	uint64_t TimeOffset = 0;
	uint64_t iTimeDiff =0;
	uint64_t iAvgSpeed =0;
	uint64_t iAvgTime  = 0;
	uint64_t iDistance = 0;

	uint64_t iMaxTime = 0xFFFFFFFF;
	    pHan->dt = xTaskGetTickCount();
	    pHan->dt = ((pHan->dt *portTICK_PERIOD_MS)/1000);

	if(pHan->iCurTime == 0)
	{
		CanProc_ResetDistanceParams(pHan);
		pHan->iCurTime = CanProc_GetCurrentTimestamp();
		pHan->iPrevTime = pHan->iCurTime;
	}
	else
	{
		pHan->iCurTime  = CanProc_GetCurrentTimestamp();

		if(pHan->iCurTime > pHan->iPrevTime)
		{
			iTimeDiff = (uint64_t)(pHan->iCurTime - pHan->iPrevTime);
		}
		else if(pHan->iCurTime < pHan->iPrevTime)
		{
			iTimeDiff =   (uint64_t)((iMaxTime - pHan->iPrevTime) + pHan->iCurTime);
		}
		else
		{
			iTimeDiff = 0;
		}

		if((iTimeDiff/24000) > 1000)
		{
			CanProc_ResetDistanceParams(pHan);
			pHan->iCurTime = CanProc_GetCurrentTimestamp();
			pHan->iPrevTime = pHan->iCurTime;
			PRINTF("\r\n Speed data timeout, Time Diff  = %d\r\n",(uint32_t)(iTimeDiff/24000));
		}
		else
		{
			pHan->bIsResetDist = 0;

			pHan->iTimeOffset[pHan->iCurIndex] = (iTimeDiff)/24000;

			pHan->iSpeed[pHan->iCurIndex] = pHan->sMotor.iSpeed;

			pHan->iCurIndex++;
			pHan->iCurIndex = pHan->iCurIndex % SPEED_CACHE_SIZE;

			for (int32_t i = 0; i < SPEED_CACHE_SIZE; i++)
			{
				iSum = iSum + pHan->iSpeed[i];
				TimeOffset = TimeOffset + pHan->iTimeOffset[pHan->iCurIndex];
			}

			iAvgSpeed = (iSum / SPEED_CACHE_SIZE);
			iAvgTime  = (TimeOffset / SPEED_CACHE_SIZE);

			iDistance = (uint64_t)(round(((double)iAvgSpeed * 1.0 * (double)iAvgTime)/36.0)); // distance in cm
			pHan->iCurOdo = (pHan->iCurOdo + iDistance);
			pHan->iCurOdoA = (pHan->iCurOdoA + iDistance);
			pHan->iCurOdoB = (pHan->iCurOdoB + iDistance);
			pHan->sMotor.iOdo = (uint32_t)(round(((double)pHan->iCurOdo*1.0)/100.0));  //iOdo is in meters
			pHan->iPrevTime = pHan->iCurTime;
		}
		iRetVal = BCU_OK;
	}
	return (iRetVal);
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_Send_DummyData					          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_Send_DummyData(CanProc_t* pHan)
{
	int iRtval = CanProc_GetCachedData(pHan);

	if(iRtval == BCU_OK)
	{
		CanProc_SendMotorInfo(pHan);
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_GetCurrentTimestamp				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static uint32_t CanProc_GetCurrentTimestamp()
{
	uint32_t lmsec  =0;
	lmsec = GPT_GetCurrentTimerCount(CANPROC_GPTIMER);
    return (lmsec);
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_TripReset		    		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_TripReset(CanProc_t* pHan,uint8_t iSelTrip)
{
	if((iSelTrip == 0) && (pHan->sMotor.iTripA != 0))
	{
		pHan->iCurTripA 	= 0;
		pHan->sMotor.iTripA = 0;
		pHan->iInitialOdoA 	= pHan->iCurOdoA;
		pHan->iPrevOdoA 	= pHan->iCurOdoA;
	}
	else if((iSelTrip == 1) && (pHan->sMotor.iTripB != 0))
	{
		pHan->iCurTripB 	= 0;
		pHan->sMotor.iTripB = 0;
		pHan->iInitialOdoB 	= pHan->iCurOdoB;
		pHan->iPrevOdoB 	= pHan->iCurOdoB;
	}

	pHan->sMotor.iOdo 	  = (uint32_t)(pHan->iCurOdo/100ULL);
	pHan->iInitialOdo 	  = pHan->iCurOdo;
	pHan->iPrevOdo 		  = pHan->iCurOdo;
	pHan->iCurOdoDiff 	  = 0;

	CanProc_SendMotorInfo(pHan);
	if(iSelTrip == 0)
	{
		CanProc_UpdateSystemInfo(pHan,eResetTripA);
//		Cluster_Controller_Manager_SystemInfo_UpdateInfo(&sUpdateinfo,eResetTripA);
	}
	else if(iSelTrip == 1)
	{
		CanProc_UpdateSystemInfo(pHan,eResetTripB);
//		Cluster_Controller_Manager_SystemInfo_UpdateInfo(&sUpdateinfo,eResetTripB);
	}
	CanProc_SendTextMsgInfo(pHan,eAlert_Trip,1);
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ProductionReset		    		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_ProductionReset(void)
{
	int32_t iRtval = BCU_NOK;
	sClusterInfo_t sUpdateinfo = {0};

	iRtval = Cluster_Controller_Manager_SystemInfo_SetSystemInfo(&sUpdateinfo,eResetInfo);
	if(iRtval == BCU_NOK)
	{
		PRINTF("\r\n ERROR: CanProc_ProductionReset\r\n");
	}

	return iRtval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SetOdoInfo			    		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_SetOdoInfo(CanProc_t* pHan,uint32_t iOdo)
{
	int32_t iRtval = BCU_NOK;

	sClusterInfo_t sUpdateinfo = {0};
	pHan->sMotor.iOdo = iOdo;
	sUpdateinfo.iOdoVal = pHan->sMotor.iOdo;
	sUpdateinfo.iCurTripA = pHan->sMotor.iTripA;
	sUpdateinfo.iCurTripB = pHan->sMotor.iTripB;

	iRtval = Cluster_Controller_Manager_SystemInfo_SetSystemInfo(&sUpdateinfo,eSetOdo);
	if(iRtval == BCU_NOK)
	{
		PRINTF("\r\n ERROR: CanProc_SetOdoInfo\r\n");
	}

	return iRtval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendMotorInfo    				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendMotorInfo(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};

	sMsg.iEventId 			= eEvent_Motor;
	memcpy((char *)sMsg.sData,(char*)(&(pHan->sMotor)),sizeof(sMotorInfo_t));

	if((pHan->qHmiMsg != NULL) && (sMsg.iEventId >0))
	{
		if(xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(10U)) != pdPASS)
		{
			pHan->iHmiDropCount++;
		}
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendBatteryInfo    				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendBatteryInfo(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};
	sMsg.iEventId 			= eEvent_Battery;
	memcpy((char *)sMsg.sData,(char*)(&(pHan->sBattery)),sizeof(sBatteryInfo_t));

	if((pHan->qHmiMsg !=NULL) && (sMsg.iEventId >0))
	{
		if(xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(10U)) != pdPASS)
		{
			pHan->iHmiDropCount++;
		}
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendTextMsgInfo  				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendTextMsgInfo(CanProc_t* pHan, eAlertId_t iId, uint32_t iCode)
{
	sMessage_t	  sMsg		= {0};
	sAlertInfo_t sAlertInfo = {0};

	if(pHan->qHmiMsg != NULL)
	{
		sMsg.iEventId 		  = eEvent_Alert;

		sAlertInfo.iId   = iId;
		sAlertInfo.iCode = iCode;
		memcpy((char *)sMsg.sData,(char*)(&(sAlertInfo)),sizeof(sAlertInfo_t));

		if(xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(10U)) != pdPASS)
		{
			pHan->iHmiDropCount++;
		}
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_GetCachedData				          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_GetCachedData(CanProc_t* pHan)
{
	int iRval = BCU_NOK;

	sClusterInfo_t sInfo = {0};

	if(pHan->bIsOdoCached == 0)
	{
		pHan->sMotor.iOdo   = 0;
		pHan->sMotor.iTripA  = 0;
		pHan->sMotor.iTripB  = 0;

		Cluster_Controller_Hal_RtcUpdateDateTime();

		iRval = Cluster_Controller_Manager_SystemInfo_GetInfo(&sInfo);
		if(iRval == BCU_OK)
		{
			if((sInfo.iOdoVal != 0xFFFFFFFF)&& ((sInfo.iCurTripA != 0xFFFFFFFF) || (sInfo.iCurTripB != 0xFFFFFFFF)))
			{
				pHan->sMotor.iSpeed = 0 ;
				pHan->sMotor.iOdo   = sInfo.iOdoVal ;
				pHan->sMotor.iTripA  = sInfo.iCurTripA;
				pHan->sMotor.iTripB  = sInfo.iCurTripB;

				pHan->iCurTripA 	= (uint64_t)(pHan->sMotor.iTripA*100ULL); // in cm
				pHan->iCurTripB 	= (uint64_t)(pHan->sMotor.iTripB*100ULL); // in cm
				pHan->iCurOdo 		= (uint64_t)(pHan->sMotor.iOdo*100ULL);
				pHan->iCurOdoA 		= (uint64_t)(pHan->sMotor.iOdo*100ULL);
				pHan->iCurOdoB 		= (uint64_t)(pHan->sMotor.iOdo*100ULL);
				pHan->iInitialOdo 	= (uint64_t)(pHan->sMotor.iOdo*100ULL);
				pHan->iInitialOdoA 	= (uint64_t)(pHan->sMotor.iOdo*100ULL);
				pHan->iInitialOdoB 	= (uint64_t)(pHan->sMotor.iOdo*100ULL);
				pHan->iPrevOdo 		= (uint64_t)(pHan->sMotor.iOdo*100ULL);
				pHan->iPrevOdoA 	= (uint64_t)(pHan->sMotor.iOdo*100ULL);
				pHan->iPrevOdoB 	= (uint64_t)(pHan->sMotor.iOdo*100ULL);
				pHan->iCurOdoDiff 	= 0;
				pHan->bIsOdoCached  = 1;
			}
			else
			{
				memset(&sInfo,0,sizeof(sInfo));
			}
		}
		else
		{
			PRINTF("\r\n Error : Failed to get Cached Data \r\n");
		}
	}
	else
	{
		pHan->sMotor.iSpeed = 0 ;
		pHan->iCurOdoDiff = 0;
		iRval = BCU_OK;
	}
	return iRval;
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateSystemInfo			          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateSystemInfo(CanProc_t* pHan, uint32_t iMode)
{
	sClusterInfo_t sUpdateinfo = {0};

	sUpdateinfo.iOdoVal = pHan->sMotor.iOdo;
	sUpdateinfo.iCurTripA = pHan->sMotor.iTripA;
	sUpdateinfo.iCurTripB = pHan->sMotor.iTripB;

	Cluster_Controller_Manager_SystemInfo_UpdateInfo(&sUpdateinfo,iMode);

	pHan->iPrevOdo = pHan->iCurOdo;
	pHan->iPrevOdoA = pHan->iCurOdoA;
	pHan->iPrevOdoB = pHan->iCurOdoB;
	pHan->iCurOdoDiff =0;

	pHan->tLastFlashWrite = xTaskGetTickCount();
	pHan->bIsInfoDirty    = false;
}
/*----------------------------------------------------------------------------*
  Function	      	:	CanProc_SendCommand
  Params	    	:
  Return value		:
  Description		:
 *----------------------------------------------------------------------------*/
static int  CanProc_SendCommand(int32_t iCanId,uint32_t iLen,uint8_t *pdata,uint8_t mbIdx,uint8_t iFormat)
{
	int iRetVal = BCU_OK;

	sCanMessage_t CanMsg;

	CanMsg.iCanId = iCanId;
	CanMsg.iFormat = iFormat;
	CanMsg.iDataLen = iLen;

	memcpy(CanMsg.sData,pdata,sizeof(CanMsg.sData));

	iRetVal = Cluster_Controller_Hal_CanSendMessage(&CanMsg,mbIdx);

	return iRetVal;
}
/*----------------------------------------------------------------------------*
  Function	      	:	CanProc_ComposeRespCommnd
  Params	    	:
  Return value		:
  Description		:
 *----------------------------------------------------------------------------*/
static int  CanProc_ComposeRespCommnd(uint8_t * pCmd, void * vpData)
{
	int32_t iRval = BCU_NOK;

	uint8_t i = 2;
	uint8_t k = 0;

	if(pCmd[0] != SLN_NUMBER)
	{
		char * pData = (char *)vpData;

		for(uint8_t j = 0; j < 12; j++)
		{
			pCmd[i] = pData[j];

			i += 1;

			if(i == 8)
			{
				i = 2;

				k += 1;

				if(k == 2)
				{
					pCmd[1] = VINFO_READ_END;
				}

				for (uint8_t m = 0; m < 8; m++)
				{
					PRINTF("%02X ", pCmd[m]);
				}

				iRval = CanProc_SendCommand(eCANID_Internal,8,&pCmd[0],15,0);

				if(iRval != BCU_OK)
				{
					PRINTF("\r\nError: CAN_PROC READ_SWHW_VERSION CAN Send failed\r\n");
				}
			}
		}
	}
	else
	{
		uint32_t * pData = (uint32_t *)vpData;

		pCmd[2] = (uint8_t)((*pData >> 24) & 0xFF);
		pCmd[3] = (uint8_t)((*pData >> 16) & 0xFF);
		pCmd[4] = (uint8_t)((*pData >> 8) & 0xFF);
		pCmd[5] = (uint8_t)(*pData & 0xFF);

		for (uint8_t m = 0; m < 8; m++)
		{
			PRINTF("%02X ", pCmd[m]);
		}

		iRval = CanProc_SendCommand(eCANID_Internal,8,&pCmd[0],15,0);

		if(iRval != BCU_OK)
		{
			PRINTF("\r\nError: CAN_PROC READ_SWHW_VERSION CAN Send failed\r\n");
		}
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_Process_UpdateDriveMode				          *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateDriveMode(CanProc_t* pHan,flexcan_frame_t* pFrame)
{
	uint8_t iVal = pFrame->dataByte0;

	if(pHan->iCurDriveStatus  != iVal)
	{
		if (iVal & 0x03)
		{
			pHan->sDriveMode.iBlink = iVal & 0x03;
		    pHan->sDriveMode.iDriveVal = eDriveMode_Reverse;
		}
		else if (iVal & 0x0C)
		{
			pHan->sDriveMode.iBlink = (iVal & 0x0C) >> 2;
		    pHan->sDriveMode.iDriveVal = eDriveMode_Sport;
		}
		else if (iVal & 0x30)
		{
			pHan->sDriveMode.iBlink = (iVal & 0x30) >> 4;
		    pHan->sDriveMode.iDriveVal = eDriveMode_Eco;
		}
		else if (iVal & 0xC0)
		{
			pHan->sDriveMode.iBlink = (iVal & 0xC0) >> 6;
		    pHan->sDriveMode.iDriveVal = eDriveMode_Ride;
		}
		else
		{
			pHan->sDriveMode.iBlink    = 0;
			pHan->sDriveMode.iDriveVal = eDriveMode_Ride;
		}

		pHan->iCurDriveStatus  = iVal;
		CanProc_SendDriveModeInfo(pHan);
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ConvertMsToTime				          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_ParseTime(CanProc_t* pHan, flexcan_frame_t* pFrame)
{
	if(pFrame != NULL)
	{
		pHan->sTime.bEnable = true;

		pHan->sTime.iMinute = pFrame->dataByte5;
		pHan->sTime.iHour = pFrame->dataByte4;

		if((pHan->iPrevTimeHrs != pHan->sTime.iHour) ||
			(pHan->iPrevTimeMins != pHan->sTime.iMinute))
		{
			pHan->iPrevTimeHrs = pHan->sTime.iHour;
			pHan->iPrevTimeMins = pHan->sTime.iMinute;
			CanProc_SendTimeDateInfo(pHan);
		}
	}
	else
	{
		pHan->sTime.bEnable = false;
		memset(&pHan->sTime, 0, sizeof(pHan->sTime));
		CanProc_SendTimeDateInfo(pHan);
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :		CanProc_SendTimeDateInfo		        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void CanProc_SendTimeDateInfo(CanProc_t* pHan)
{
	sMessage_t sMsg   = {0};

	sMsg.iEventId     = eEvent_Time;
	memcpy((char *)sMsg.sData,(char*)(&pHan->sTime),sizeof(sTimeInfo_t));

	if((pHan->qHmiMsg  != NULL) && (sMsg.iEventId > 0))
	{
		xQueueSend(pHan->qHmiMsg, &sMsg, (TickType_t)(MSG_SEND_DEFAULT_WAIT));
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendDriveModeInfo				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendDriveModeInfo(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};
	if(pHan->qHmiMsg != NULL)
	{
		sMsg.iEventId 			= eEvent_DriveMode;
		memcpy((char *)sMsg.sData,(char*)(&(pHan->sDriveMode)),sizeof(sDriveMode_t));
		xQueueSend(pHan->qHmiMsg, &sMsg, (TickType_t)(MSG_SEND_DEFAULT_WAIT));
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateStatus0						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateStatus0(CanProc_t* pHan ,flexcan_frame_t* pFrame)
{
	pHan->sStatus0.iIndRight  = (((pFrame->dataByte1) & 0x0C) >> 2);	//0x01 : Blink, 0x03:Solid
	pHan->sStatus0.iIndLeft   = (((pFrame->dataByte1) & 0x30) >> 4);

	pHan->sStatus0.iHighBeam  = (((pFrame->dataByte2) & 0x30) >> 4);
	pHan->sStatus0.iLowBeam   = (((pFrame->dataByte2) & 0xC0) >> 6);

	pHan->sStatus0.iSideStand = (((pFrame->dataByte3) & 0xC0) >> 6);
    pHan->sStatus0.iHazard 	  = (((pFrame->dataByte3) & 0x0C) >> 2);	//0x01 : Blink, 0x03:Solid

    pHan->sStatus0.iDoorLock 	= (((pFrame->dataByte6) & 0x60) >> 5);

    if(( pHan->sStatus0.iDoorLock != 0) || (pHan->sStatus0.iSideStand !=0))
    {
    	pHan->sStatus0.iParkingMode = 1;
    }
    else
    {
    	pHan->sStatus0.iParkingMode = 0;
    }
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateStatus1				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateStatus1(CanProc_t* pHan ,flexcan_frame_t* pFrame)
{
	pHan->sStatus1.iBle     = ((pFrame->dataByte5) & 0x03);			//0x01 : Blink, 0x03:Solid
	pHan->sStatus1.iRegen   = (((pFrame->dataByte5) & 0x0C) >> 2);	/* Reserved */
	pHan->sStatus1.iNetwork = (((pFrame->dataByte5) & 0x30) >> 4);	/* Reserved */
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateStatus0_Info						      *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateStatus0_Info(CanProc_t* pHan)
{
	if((pHan->sCurrStatus0.iIndRight 		!= pHan->sStatus0.iIndRight) ||
		(pHan->sCurrStatus0.iIndLeft 		!= pHan->sStatus0.iIndLeft) ||
		(pHan->sCurrStatus0.iHighBeam 		!= pHan->sStatus0.iHighBeam) ||
		(pHan->sCurrStatus0.bBatteryPackState != pHan->sStatus0.bBatteryPackState) ||
		(pHan->sCurrStatus0.iService	 	!= pHan->sStatus0.iService) ||
		(pHan->sCurrStatus0.iSideStand 		!= pHan->sStatus0.iSideStand) ||
		(pHan->sCurrStatus0.iParkingMode 	!= pHan->sStatus0.iParkingMode) ||
		(pHan->sCurrStatus0.iParkingBreak 	!= pHan->sStatus0.iParkingBreak) ||
		(pHan->sCurrStatus0.iHazard 		!= pHan->sStatus0.iHazard) ||
		(pHan->sCurrStatus0.iDoorLock 		!= pHan->sStatus0.iDoorLock) ||
		(pHan->sStatus0.iCount > 50))
	{
		pHan->sCurrStatus0.iIndRight  		= pHan->sStatus0.iIndRight;
		pHan->sCurrStatus0.iIndLeft   		= pHan->sStatus0.iIndLeft;
		pHan->sCurrStatus0.iHighBeam 		= pHan->sStatus0.iHighBeam;
		pHan->sCurrStatus0.bBatteryPackState = pHan->sStatus0.bBatteryPackState;
		pHan->sCurrStatus0.iService 	 	= pHan->sStatus0.iService;
		pHan->sCurrStatus0.iSideStand 		= pHan->sStatus0.iSideStand;
		pHan->sCurrStatus0.iParkingMode 	= pHan->sStatus0.iParkingMode;
		pHan->sCurrStatus0.iParkingBreak 	= pHan->sStatus0.iParkingBreak;
		pHan->sCurrStatus0.iHazard 			= pHan->sStatus0.iHazard;
		pHan->sCurrStatus0.iDoorLock 		= pHan->sStatus0.iDoorLock;

		CanProc_SendStatus0_Info(pHan);
		pHan->sStatus0.iCount = 0;
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateStatus4_Info						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateStatus1_Info(CanProc_t* pHan)
{
	if((pHan->sCurrStatus1.iBle  != pHan->sStatus1.iBle) ||
		(pHan->sCurrStatus1.iRegen 	!= pHan->sStatus1.iRegen) ||
		(pHan->sCurrStatus1.iNetwork != pHan->sStatus1.iNetwork) ||
		(pHan->sStatus1.iCount > 50))
	{
		pHan->sCurrStatus1.iBle 	= pHan->sStatus1.iBle;
		pHan->sCurrStatus1.iRegen 	= pHan->sStatus1.iRegen;
		pHan->sCurrStatus1.iNetwork = pHan->sStatus1.iNetwork;

		CanProc_SendStatus1_Info(pHan);
		pHan->sStatus1.iCount = 0;
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendStatus0_Info			          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendStatus0_Info(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};

	sMsg.iEventId 			= eEvent_Status0;

	memcpy((char *)sMsg.sData,(char*)(&(pHan->sStatus0)),sizeof(sStatus0_t));
	if((pHan->qHmiMsg != NULL) && (sMsg.iEventId > 0))
	{
		if(xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(10U)) != pdPASS)
		{
			pHan->iHmiDropCount++;
		}
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendStatus1_Info			          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendStatus1_Info(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};

	sMsg.iEventId 			= eEvent_Status1;

	memcpy((char *)sMsg.sData,(char*)(&(pHan->sStatus1)),sizeof(sStatus1_t));
	if((pHan->qHmiMsg != NULL) && (sMsg.iEventId > 0))
	{
		if(xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(10U)) != pdPASS)
		{
			pHan->iHmiDropCount++;
		}
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_Process_FaultMsgHandler			    		  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_Process_FaultMsgHandler(void *args)
{
    CanProc_t* pHan = (CanProc_t*)args;

    uint8_t sActiveFaults[MAX_ERROR_ID + 1] = {0};
    uint16_t iCurIndex = 0;
    uint16_t iActiveCount = 0;
    uint16_t iTimeoutCount = 0;
    TickType_t iDelay = pdMS_TO_TICKS(5000);
    sFaultMsg_t sMsg;

    while (1)
    {
        uint32_t iPriorityTransmitId = 0xFFFF;

        if (pdPASS == xQueueReceive(pHan->qErMsg, &sMsg, iDelay))
        {
            uint32_t iNewId = sMsg.iId;
            iTimeoutCount = 0;

            if (iNewId == 0xFFFF)
            {
                memset(sActiveFaults, 0, sizeof(sActiveFaults));

                iActiveCount = 0;
                iCurIndex = 0;
            }
            else if (iNewId <= MAX_ERROR_ID)
            {
                if (sActiveFaults[iNewId] == 0)
                {
                    sActiveFaults[iNewId] = 1;

                    iActiveCount++;

                    iPriorityTransmitId = iNewId;
                }
            }
        }
        else
        {
            if (iActiveCount > 0)
            {
                iTimeoutCount++;

                if (iTimeoutCount >= 1)
                {
                    memset(sActiveFaults, 0, sizeof(sActiveFaults));

                    iActiveCount = 0;
                    iCurIndex = 0;
                    iTimeoutCount = 0;
                }
            }
        }

        if (iActiveCount == 0)
        {
            pHan->vFaultInfo.iId = 0xFFFF;
            pHan->vFaultInfo.iCode = 0;
            pHan->vFaultInfo.iCount = 0;

            snprintf(pHan->sFault.sMsg,ERROR_BUF_LEN,"%s",Get_FaultMessage(0));

            pHan->sFault.bEnable = false;

            CanProc_SendFaultInfo(pHan);

            iDelay = pdMS_TO_TICKS(10000);

            iCurIndex = 0;
            iTimeoutCount = 0;

            continue;
        }

        uint32_t iTransmitId = 0xFFFF;
        if (iPriorityTransmitId != 0xFFFF)
        {
            iTransmitId = iPriorityTransmitId;
        }
        else
        {
            if (iCurIndex > MAX_ERROR_ID)
            {
                iCurIndex = 0;
            }
            if (sActiveFaults[iCurIndex] == 1)
            {
                iTransmitId = iCurIndex;
            }
        }

        if (iTransmitId != 0xFFFF)
        {
            pHan->vFaultInfo.iId = iTransmitId;
            pHan->vFaultInfo.iCode = 1;
            pHan->vFaultInfo.iCount = iActiveCount;

            CanProc_SendFaultInfo(pHan);

            iDelay = pdMS_TO_TICKS(5000);

            if (iPriorityTransmitId == 0xFFFF)
            {
                iCurIndex++;
            }
        }
    }
}
/*----------------------------------------------------------------------------*
  Function	      	:	CanProc_SendFaultInfo
  Params	    	:
  Return value		:
  Description		:
 *----------------------------------------------------------------------------*/
static void CanProc_SendFaultInfo(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};
	sMsg.iEventId 			= eEvent_VFault;

	memcpy((char *)sMsg.sData,(char *)(&(pHan->vFaultInfo)),sizeof(sVFaultInfo_t));
	if((pHan->qHmiMsg !=NULL) && (sMsg.iEventId >0))
	{
		xQueueSend(pHan->qHmiMsg, &sMsg, (TickType_t)(MSG_SEND_DEFAULT_WAIT));
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_Process_TextMsgFaults		          	  	      *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_Process_TextMsgFaults(CanProc_t* pHan,flexcan_frame_t* pFrame)
{
	uint16_t iFaultId = pFrame->dataByte2 & 0x0F;

	if ((iFaultId & 0x0C) != 0)
	{
	    iFaultId = 1;    //Battery fault
	}
	else if ((iFaultId & 0x03) != 0)
	{
	    iFaultId = 0;    //Motor fault
	}
	else
	{
	    iFaultId = 0xFFFF;    //No fault
	}

	pHan->sQueueFault.iId =  iFaultId;
	xQueueSend(pHan->qErMsg,&pHan->sQueueFault,(TickType_t)(MSG_SEND_DEFAULT_WAIT));
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UIUpdateHandler			    		  		  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UIUpdateHandler(void *args)
{
	CanProc_t *pHan = (CanProc_t *)args;
	uint8_t sBuf[DUR_QUEUE_BUFFER_SIZE];

	uint8_t iState = 0;
	const TickType_t sWaitTicks = pdMS_TO_TICKS(50);

	while (1)
	{
		xQueueReceive(pHan->qUpdateMsg, &sBuf[0], sWaitTicks);

		switch(iState)
		{
			case 0:
				CanProc_UpdateStatus0_Info(pHan);
			break;
			case 1:
				CanProc_UpdateSpeedInfo(pHan,eSpeedInfo);
			break;
			case 2:
				CanProc_UpdateBatteryInfo(pHan);
				CanProcStatus_UpdateChargeInfo(pHan);
			break;
			case 3:
				CanProc_UpdateStatus1_Info(pHan);
			break;
			default:
			break;
		}
		iState++;

		if(iState > 3)
		{
			iState = 0;
		}
	}
}
