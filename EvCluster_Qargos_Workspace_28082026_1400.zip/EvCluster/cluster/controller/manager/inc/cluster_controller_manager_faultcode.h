#ifndef CONTROLLER_MANAGER_FAULTCODE_H_
#define CONTROLLER_MANAGER_FAULTCODE_H_

#ifdef __cplusplus
 extern "C" {
#endif

 /*-----------------------------------------------------------------------------*
  *	OptM Media Solutions Confidential										    *
  *	Copyright (C) OptM Media Solutions Pvt. Ltd - All Rights Reserved	   	    *
  *																			    *
  *  Dissemination of this information or reproduction or redistribution of 	*
  *  this material is  strictly forbidden unless prior written permission is	*
  *  oCanained from OptM Media Solutions Pvt Ltd								*
  *	 File Name	:	cluster_hal_spi.h											*
  *	 version		: 											              	*
  *  Date		:	03-Mar-2023													*
  *  Description :  				 										 	*
  *                               						                        *
  *																			    *
  *-----------------------------------------------------------------------------*/
#include <stdint.h>

 typedef struct {
     uint32_t iId;
     const char* sMsg;
 } sFaultMsg_t;

 static const sFaultMsg_t gFaultTable[] =
 {
     {0,   u8" "},
     {1,   u8" ERROR CODE : MOTOR FAULT "},
     {2,   u8" ERROR CODE : MOTOR FAULT "},
     {3,   u8" ERROR CODE : MOTOR FAULT "},
     {4,   u8" "},
     {5,   u8" ERROR CODE : BATTERY FAULT "},
     {6,   u8" ERROR CODE : BATTERY FAULT "},
     {7,   u8" ERROR CODE : BATTERY FAULT "},
 };


 //Total Fault Count
#define FAULT_TABLE_SIZE  (sizeof(gFaultTable) / sizeof(gFaultTable[0]))

/* 	Get Fault Message	*/
static inline const char* Get_FaultMessage(uint16_t faultId)
{
    for(uint16_t i = 0; i < FAULT_TABLE_SIZE; i++)
    {
        if(gFaultTable[i].iId == faultId)
        {
            return gFaultTable[i].sMsg;
        }
    }
    return "\r\n Unknown Fault Code\r\n";
}

#ifdef __cplusplus
}
#endif

#endif /* CONTROLLER_MANAGER_FAULTCODE_H_ */
