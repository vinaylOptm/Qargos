/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt. Ltd - All Rights Reserved	   	   *
 *																			   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_hal_buzzer.h							   *
 *  version		: 											              	   *
 *  Date		:	13-Mar-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *																			   *
 *-----------------------------------------------------------------------------*/

#ifndef CLUSTER_CONTROLLER_HAL_BUZZER_H
#define CLUSTER_CONTROLLER_HAL_BUZZER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

/*-----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_Buzzer_Init		        		   *
 * Params	    :					        		                           *
 * Return value	:	BCU_OK on success, BCU_NOK on failure	                   *
 * Description	:	Initialises PWM peripheral, command queue and buzzer task  *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Buzzer_Init(void);

/*-----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_Buzzer_DeInit		        	   *
 * Params	    :					        		                           *
 * Return value	:	BCU_OK								                       *
 * Description	:	Stops task, deletes queue and deinitialises PWM peripheral *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Buzzer_DeInit(void);

/*-----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_Buzzer_Enable		       		   *
 * Params	    :	bEnable     - true to activate, false to deactivate        *
 *				    iDurationMs - duration of one beep in milliseconds         *
 *				                  (set 0 with iBeepCount=0 for continuous mode)*
 *				    iBeepCount  - number of beeps (0 = continuous mode)        *
 * Return value	:	BCU_OK on success, BCU_NOK if not initialised/queue full   *
 * Description	:	Posts a buzzer command to the internal command queue        *
 *-----------------------------------------------------------------------------*/

 int32_t Cluster_Controller_Hal_Buzzer_Enable(bool bEnable,uint32_t iDurationMs,uint32_t iBeepCount);
#ifdef __cplusplus
}
#endif

#endif /* CLUSTER_CONTROLLER_HAL_BUZZER_H */
