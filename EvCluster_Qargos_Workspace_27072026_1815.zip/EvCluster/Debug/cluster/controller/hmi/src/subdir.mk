################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../cluster/controller/hmi/src/cpp_config.cpp \
../cluster/controller/hmi/src/hmihandler.cpp 

CPP_DEPS += \
./cluster/controller/hmi/src/cpp_config.d \
./cluster/controller/hmi/src/hmihandler.d 

OBJS += \
./cluster/controller/hmi/src/cpp_config.o \
./cluster/controller/hmi/src/hmihandler.o 


# Each subdirectory must supply rules for building sources it contributes
cluster/controller/hmi/src/%.o: ../cluster/controller/hmi/src/%.cpp cluster/controller/hmi/src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C++ Compiler'
	arm-none-eabi-c++ -std=gnu++14 -DCPU_MIMXRT1176AVM8A -DCLUSTER_PANEL_WIDTH=800 -DCLUSTER_PANEL_HEIGHT=480 -DCLUSTER_KEYIGNITION_SUPPORTED=1 -DUDS_SERVICE_ENABLE=0 -DEEPROM=0 -DBLE_ENABLED=0 -DCLUSTER_HW_VERSION=2 -DCLUSTER_DISPLAY=2 -DCLUSTER_DISPLAY_INTERFACE=0 -DCLUSTER_NAVIGATION_SWITCH_ENABLE=1 -DCPU_MIMXRT1176AVM8A_cm7 -DCPU_MIMXRT1176DVMAA -DCPU_MIMXRT1176DVMAA_cm7 -DCPU_MIMXRT1062DVL6A_cm7 -DSDK_OS_BAREMETAL -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSERIAL_PORT_TYPE_UART=1 -DXIP_BOOT_HEADER_DCD_ENABLE=1 -DXIP_BOOT_HEADER_XMCD_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -DSDK_OS_FREE_RTOS -D__USE_CMSIS -DDEBUG -D__NEWLIB__ -DCPP_NO_HEAP -DFSL_RTOS_FREE_RTOS -D"PRINTF_ADVANCED_ENABLE =0" -D"PRINTF_FLOAT_ENABLE =0" -D"SCANF_ADVANCED_ENABLE =0" -DSCANF_FLOAT_ENABLE=0 -DSKIP_SYSCLK_INIT -DUSE_SDRAM -DSDK_I2C_BASED_COMPONENT_USED=1 -DVGLITE_POINT_FILTERING_FOR_SIMPLE_SCALE -DQUL_STD_STRING_SUPPORT -DENABLE_PWM_CONTROL=0 -DSDIO_ENABLED -DDATA_SECTION_IS_CACHEABLE=1 -DCUSTOM_VGLITE_MEMORY_CONFIG=0 -DVG_COMMAND_CALL=1 -DVG_TARGET_FAST_CLEAR=0 -DSDK_DEBUGCONSOLE_UART -DDEBUG_CONSOLE_RX_ENABLE=0 -DFSL_SDK_DRIVER_QUICK_ACCESS_ENABLE=1 -DCR_INTEGER_PRINTF -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\GeneratedHmi\qargos_ui" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\board" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\osa" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\plf\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\freertos\freertos-kernel\include" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\freertos\freertos-kernel\portable\GCC\ARM_CM4F" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\drivers" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\xip" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\device" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\CMSIS" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\serial_manager" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\uart" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\utilities" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\video" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\lists" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\startup" -I"C:\Qt\QtMCUs\2.5.0\include" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\qoi" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\minihdlc" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\nanopb" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos\display" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLite\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLiteKernel" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLiteKernel\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\config" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\hal\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\manager\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\hmi\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\gpio" -O0 -fno-common -g3 -Wall -c -ffunction-sections -fdata-sections -ffreestanding -fno-builtin -fno-rtti -fno-exceptions -imacros "D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\source\wifi_config.h" -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-cluster-2f-controller-2f-hmi-2f-src

clean-cluster-2f-controller-2f-hmi-2f-src:
	-$(RM) ./cluster/controller/hmi/src/cpp_config.d ./cluster/controller/hmi/src/cpp_config.o ./cluster/controller/hmi/src/hmihandler.d ./cluster/controller/hmi/src/hmihandler.o

.PHONY: clean-cluster-2f-controller-2f-hmi-2f-src

