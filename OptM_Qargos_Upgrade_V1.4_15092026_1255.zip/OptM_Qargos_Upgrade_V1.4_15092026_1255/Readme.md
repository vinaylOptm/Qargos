Fw: OptM_EvCluster_Qargos_V1.4.axf
Version : V1.4
Date: 11/09/2026

Changes info:

1) Included Thermal Runaway: Fault Msg
2) Fault Msg fonts size are increased for visibility.
3) Motor ON color change.