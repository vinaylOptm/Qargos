
#include <qul/application.h>
#include <qul/qul.h>
#include <platforminterface/log.h>
#include <FreeRTOS.h>
#include <task.h>
#include <board.h>
#include "display/vglitecontroller.h"
#include <hmimain.h>
#include "fsl_debug_console.h"
#include "fsl_iomuxc.h"
#include "cluster_controller_platform.h"
#include "cluster_common.h"

static void Qul_Thread(void *argument);
static void ControllerPlatform_Thread(void *argument);
#include <stdint.h>



#define QUL_THREAD_STACK_WORDS       (63 * 1024)
#define PLATFORM_THREAD_STACK_WORDS  (63 * 1024)
int main()
{



    Qul::initHardware();



    Qul::initPlatform();





    TaskHandle_t xQulTask = NULL;
    if (xTaskCreate(Qul_Thread, "Qul_Thread", QUL_THREAD_STACK_WORDS, 0, CLUSTER_TASK_PRIORITY_UI, &xQulTask) != pdPASS) {
        Qul::PlatformInterface::log("Qul_Thread creation failed\r\n");
        configASSERT(false);
    }

    if (xTaskCreate(ControllerPlatform_Thread, "ControllerPlfThread", PLATFORM_THREAD_STACK_WORDS, 0, CLUSTER_TASK_PRIORITY_DATA, 0) != pdPASS) {
        Qul::PlatformInterface::log("ControllerPlatform_Thread creation failed\r\n");
        if(xQulTask != NULL) { vTaskDelete(xQulTask); }
        configASSERT(false);
    }

    vTaskStartScheduler();

    return 1;
}

static void Qul_Thread(void *argument)
{
    (void) argument;
    Qul::Application _qul_app;
    static struct ::hmimain _qul_item;
    _qul_app.setRootItem(&_qul_item);

#ifdef APP_DEFAULT_UILANGUAGE
    _qul_app.settings().uiLanguage.setValue(APP_DEFAULT_UILANGUAGE);
#endif

    _qul_app.exec();
}

static void ControllerPlatform_Thread(void *argument)
{
	ControllerPlatform::Start();
}


extern "C" {
void vApplicationStackOverflowHook(TaskHandle_t xTask, signed char *pcTaskName)
{
    (void) xTask;
    (void) pcTaskName;

    Qul::PlatformInterface::log("vApplicationStackOverflowHook");
    configASSERT(false);
}

void vApplicationMallocFailedHook(void)
{
    Qul::PlatformInterface::log("vApplicationMallocFailedHook");
    configASSERT(false);
}
}
