################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../video/fsl_dc_fb_elcdif.c \
../video/fsl_dc_fb_lcdifv2.c \
../video/fsl_fbdev.c \
../video/fsl_hx8394.c \
../video/fsl_mipi_dsi_cmd.c \
../video/fsl_rm68191.c \
../video/fsl_rm68200.c \
../video/fsl_video_common.c \
../video/pca6416.c \
../video/pca9530.c \
../video/rpi.c 

C_DEPS += \
./video/fsl_dc_fb_elcdif.d \
./video/fsl_dc_fb_lcdifv2.d \
./video/fsl_fbdev.d \
./video/fsl_hx8394.d \
./video/fsl_mipi_dsi_cmd.d \
./video/fsl_rm68191.d \
./video/fsl_rm68200.d \
./video/fsl_video_common.d \
./video/pca6416.d \
./video/pca9530.d \
./video/rpi.d 

OBJS += \
./video/fsl_dc_fb_elcdif.o \
./video/fsl_dc_fb_lcdifv2.o \
./video/fsl_fbdev.o \
./video/fsl_hx8394.o \
./video/fsl_mipi_dsi_cmd.o \
./video/fsl_rm68191.o \
./video/fsl_rm68200.o \
./video/fsl_video_common.o \
./video/pca6416.o \
./video/pca9530.o \
./video/rpi.o 


# Each subdirectory must supply rules for building sources it contributes
video/%.o: ../video/%.c video/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCLUSTER_PANEL_WIDTH=800 -DCLUSTER_PANEL_HEIGHT=480 -DUDS_SERVICE_ENABLE=0 -DEEPROM=0 -DBLE_ENABLED=0 -DCLUSTER_HW_VERSION=2 -DCLUSTER_DISPLAY_INTERFACE=0 -DCLUSTER_DISPLAY=2 -DCLUSTER_NAVIGATION_SWITCH_ENABLE=1 -DCPU_MIMXRT1176AVM8A -DCPU_MIMXRT1176DVMAA_cm7 -DCPU_MIMXRT1176DVMAA -DCPU_MIMXRT1176AVM8A_cm7 -DSDK_OS_BAREMETAL -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSERIAL_PORT_TYPE_UART=1 -DXIP_BOOT_HEADER_DCD_ENABLE=1 -DXIP_BOOT_HEADER_XMCD_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -DSDK_OS_FREE_RTOS -D__USE_CMSIS -DDEBUG -DCPP_NO_HEAP -DFSL_RTOS_FREE_RTOS -D"PRINTF_ADVANCED_ENABLE =0" -D"PRINTF_FLOAT_ENABLE =0" -D"SCANF_ADVANCED_ENABLE =0" -DSCANF_FLOAT_ENABLE=0 -DSKIP_SYSCLK_INIT -DUSE_SDRAM -DSDK_I2C_BASED_COMPONENT_USED=1 -DENABLE_PWM_CONTROL=0 -DCLUSTER_KEYIGNITION_SUPPORTED=1 -DSDIO_ENABLED -DDATA_SECTION_IS_CACHEABLE=1 -DCUSTOM_VGLITE_MEMORY_CONFIG=0 -DVG_COMMAND_CALL=1 -DVG_TARGET_FAST_CLEAR=0 -DSDK_DEBUGCONSOLE_UART -DDEBUG_CONSOLE_RX_ENABLE=0 -DFSL_SDK_DRIVER_QUICK_ACCESS_ENABLE=1 -DCR_INTEGER_PRINTF -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\board" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\osa" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\hmi\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\opensource\cjson" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\freertos\freertos-kernel\include" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\freertos\freertos-kernel\portable\GCC\ARM_CM4F" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\drivers" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\xip" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\device" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\CMSIS" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\serial_manager" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\uart" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\utilities" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\video" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\lists" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\startup" -I"C:\Qt\QtMCUs\2.5.0\include" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\qoi" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\minihdlc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\common" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\nanopb" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos\display" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLite\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLiteKernel" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLiteKernel\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\config" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\hal\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\manager\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\gpio" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\GeneratedHmi\qargos_ui" -O0 -fno-common -g3 -Wall -Wextra -Wconversion -Wcast-align -Wcast-qual -Wdisabled-optimization -Wlogical-op -Wmissing-declarations -Wredundant-decls -Wshadow -Wsign-conversion -Wswitch-default -Wundef -Wfloat-equal -c -ffunction-sections -fdata-sections -ffreestanding -fno-builtin -imacros "D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\source\wifi_config.h" -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-video

clean-video:
	-$(RM) ./video/fsl_dc_fb_elcdif.d ./video/fsl_dc_fb_elcdif.o ./video/fsl_dc_fb_lcdifv2.d ./video/fsl_dc_fb_lcdifv2.o ./video/fsl_fbdev.d ./video/fsl_fbdev.o ./video/fsl_hx8394.d ./video/fsl_hx8394.o ./video/fsl_mipi_dsi_cmd.d ./video/fsl_mipi_dsi_cmd.o ./video/fsl_rm68191.d ./video/fsl_rm68191.o ./video/fsl_rm68200.d ./video/fsl_rm68200.o ./video/fsl_video_common.d ./video/fsl_video_common.o ./video/pca6416.d ./video/pca6416.o ./video/pca9530.d ./video/pca9530.o ./video/rpi.d ./video/rpi.o

.PHONY: clean-video

