#ifndef CLUSTER_CONTROLLER_HAL_H_
#define CLUSTER_CONTROLLER_HAL_H_

#ifdef __cplusplus
 extern "C" {
#endif

/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt. Ltd - All Rights Reserved	   	   *
 *																			   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_hal.h 								  	   		   
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023													   
 *  Description :  				 										 	   * 
 *                               						                       *
 *																			   *
 *-----------------------------------------------------------------------------*/
 
 
/*----------------------------------------------------------------------------*
 * Include Headers				           	                             	  *
 *----------------------------------------------------------------------------*/
#include <stdio.h>
#include "cluster_common.h"
#include "FreeRTOS.h"
#include "queue.h"


/*----------------------------------------------------------------------------*
 * Structure and enum definations				                              * 
 *----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*
 * Methods                      				                              *
 *----------------------------------------------------------------------------*/
 
 
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Init(int32_t iModules);

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_DeInit(int32_t iModules);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/ 
int32_t Cluster_Controller_Hal_SetReceiveQueueHandle(int32_t iModule,QueueHandle_t qRxMsg);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_EnableModule(int32_t iModule,int32_t iEnable);
/*-----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_CanSendMessage  			     	   *
 * Params	    :	Can Message to be sent     		                           *
 * Return value	:	BCU_OK or BCU_NOK				                           *
 * Description	:	sends Message to the device usng CAN                       *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_CanSendMessage(sCanMessage_t *pMsg,uint8_t mbIdx);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_BTSendMessage(uint8_t *pMsg,uint32_t iMsgLen);
 
/*----------------------------------------------------------------------------*
  * Function	    :										        	   	      *
  * Params	    :				        		                          	  *
  * Return value	:									                          *
  * Description	:									                          *
  *----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_RtcGetDateTime(sTimeInfo_t * pInfo);

 /*----------------------------------------------------------------------------*
  * Function	    :										        	   	      *
  * Params	    :				        		                          	  *
  * Return value	:									                          *
  * Description	:									                          *
  *----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_RtcSetDateTime(sTimeInfo_t * pInfo);
 
 
 /*-----------------------------------------------------------------------------*
  * Function	    :											        		*
  * Params	    :					        		                            *
  * Return value	:									                        *
  * Description	:							                                    *
  *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_BacklightSetBrightness(uint8_t iValue);
  /*-----------------------------------------------------------------------------*
    * Function	    :											        		*
    * Params	    :					        		                            *
    * Return value	:									                        *
    * Description	:							                                    *
    *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_FlashWriteData(uint8_t * pBuf, uint32_t iSize,uint32_t iAddr);
 /*-----------------------------------------------------------------------------*
    * Function	    :											        		*
    * Params	    :					        		                            *
    * Return value	:									                        *
    * Description	:							                                    *
    *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_FlashReadData(uint8_t * pBuf, uint32_t iSize,uint32_t iAddr);
 /*-----------------------------------------------------------------------------*
    * Function	    :											        		*
    * Params	    :					        		                            *
    * Return value	:									                        *
    * Description	:							                                    *
    *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_FlashErase(uint32_t iAddr);
 /*-----------------------------------------------------------------------------*
    * Function	    :											        		*
    * Params	    :					        		                            *
    * Return value	:									                        *
    * Description	:							                                    *
    *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_FlashReadProp(int iParam,uint8_t * pBuf, uint32_t iSize,uint32_t iAddr);
 /*-----------------------------------------------------------------------------*
    * Function	    :											        		*
    * Params	    :					        		                            *
    * Return value	:									                        *
    * Description	:							                                    *
    *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_RtcUpdateDateTime(void);
 /*-----------------------------------------------------------------------------*
  * Function	    :											        		   *
  * Params	    :					        		                           *
  * Return value	:									                           *
  * Description	:							                                   *
  *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_BacklightSetBrightnessLevel(uint32_t iLevel);

 /*-----------------------------------------------------------------------------*
  * Function	    :											        		   *
  * Params	    :					        		                           *
  * Return value	:									                           *
  * Description	:							                                   *
  *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_CanReset(bool bIsr);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_CanSleep(bool bSleep);

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
void Cluster_Controller_Hal_FirmwareDownload_Init();
 /*-----------------------------------------------------------------------------*
  * Function	    :											        		   *
  * Params	    :					        		                           *
  * Return value	:									                           *
  * Description	:							                                   *
  *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_CanGetMode(void);
 /*-----------------------------------------------------------------------------*
  * Function	    :											        	    *
  * Params	    :					        		                            *
  * Return value	:									                        *
  * Description	:							                                    *
  *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_CanEnable(void);
 /*-----------------------------------------------------------------------------*
  * Function	    :											        	    *
  * Params	    :					        		                            *
  * Return value	:									                        *
  * Description	:							                                    *
  *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_RtcSetMode(bool bSetMode);
 /*-----------------------------------------------------------------------------*
  * Function	    :											        	    *
  * Params	    :					        		                            *
  * Return value	:									                        *
  * Description	:							                                    *
  *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_ConfigGetVersion(uint32_t * iSwVersion,uint32_t *iHwVersion);
 /*-----------------------------------------------------------------------------*
  * Function	    :											        	    *
  * Params	    :					        		                            *
  * Return value	:									                        *
  * Description	:							                                    *
  *-----------------------------------------------------------------------------*/
 void Cluster_Controller_Hal_ConfigGetSwHwVersion(char * pSwVersion,char * pHwVersion);
/*-----------------------------------------------------------------------------*
* Function	    :											        		   *
* Params	    :					        		                           *
* Return value	:									                           *
* Description	:							                                   *
*-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_ConfigGetStackSize(uint16_t* pVal);
 /*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
 uint32_t Cluster_Controller_Hal_ConfigGetFlashAddress(uint32_t iSectorAddr);
 /*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_ConfigBtGetInterface(uint32_t* pId, uint32_t* pBaudRate);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigCanGetInterface(int32_t* pId, uint32_t* pBaudRate);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
uint32_t Cluster_Controller_Hal_ConfigGetMaxCanId(void);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
sCanConfig_t* Cluster_Controller_Hal_ConfigGetCanIdList(void);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigRtcGetInterface(uint32_t * pId, uint32_t * pBaudRate);
/*-----------------------------------------------------------------------------*
* Function	    :											        		   *
* Params	    :					        		                           *
* Return value	:									                           *
* Description	:							                                   *
*-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigRtcGetInterruptConf(int32_t* pVal);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
uint32_t* Cluster_Controller_Hal_ConfigSwitchGetList(int Id);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigBacklightGetInterface(uint8_t* pId, uint32_t* pFreq);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
uint8_t*  Cluster_Controller_Hal_ConfigGetBrightnessMap(void);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigGetDefaultBrightnessLevel(uint32_t* pVal);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigGetMaxBrightnessLevel(uint32_t* pVal);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
 uint32_t Cluster_Controller_Hal_ConfigFlashInterface(uint32_t * pBase,
													  uint32_t * pPCS0,
													  uint32_t * pClk,
													  uint32_t * pSdo,
													  uint32_t * pSdi);
/*-----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_BuzzerEnable		        		   *
 * Params	    :	bEnable     - true to activate, false to deactivate        *
 *				    iDuration   - beep half-period in ms (0 = continuous mode) *
 *				    iBeepCount  - number of beeps (0 = continuous mode)        *
 * Return value	:	BCU_OK on success, BCU_NOK if not initialised/queue full   *
 * Description	:	Posts a buzzer command to the internal command queue        *
 *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_BuzzerEnable(bool bEnable,bool bContinuous, uint32_t iDuration, uint32_t iBeepCount);
/*-----------------------------------------------------------------------------*
* Function	    :											        		   *
* Params	    :					        		                           *
* Return value	:									                           *
* Description	:							                                   *
*-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_HalDisplay_Enable(bool bOnOff);
/*-----------------------------------------------------------------------------*
* Function	    :											        	    *
* Params	    :					        		                            *
* Return value	:									                        *
* Description	:							                                    *
*-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigSpiGetInterface(int32_t* pId, uint32_t* pBaudRate);
#ifdef __cplusplus
}
#endif


#endif /* CLUSTER_CONTROLLER_HAL_H_ */
