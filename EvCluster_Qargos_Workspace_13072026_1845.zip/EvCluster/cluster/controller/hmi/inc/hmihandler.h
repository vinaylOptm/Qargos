#ifndef HMIHANDLER_H
#define HMIHANDLER_H

#include <qul/singleton.h>
#include <qul/property.h>
#include <qul/eventqueue.h>
#include <string>
#include <stdint.h>
typedef std::basic_string<char, std::char_traits<char>, Qul::PlatformInterface::Allocator<char> > QulString;
struct HmiHandler : public Qul::Singleton<HmiHandler>
{
    friend struct Qul::Singleton<HmiHandler>;
	
    Qul::Property<QulString> sDirMsg;
    Qul::Property<QulString> sCallNum;
    Qul::Property<QulString> sBtMsg;
    Qul::Property<QulString> sSwVer;
    Qul::Property<QulString> sHwVer;
    Qul::Property<QulString> sSerialNum;
    Qul::Property<QulString> sErrorMsg;
	enum ClusterEvents_t
	{
		Event_None				= 0,
		Event_Motor				= 1,
		Event_Battery			= 2,
		Event_Charge			= 3,
		Event_ChargeAlert   	= 4,
		Event_Time             	= 5,
		Event_DriveMode			= 6,
		Event_NavSwitch			= 7,
		Event_HwIndicator		= 8,
		Event_Call				= 9,
		Event_DeviceStatus		= 10,
		Event_TurnByTurnNav		= 11,
		Event_Message			= 12,
		Event_BTMessage      	= 13,
		Event_Alert				= 14,
		Event_Fault				= 15,
		Event_Indicator			= 16,
		Event_Standby			= 17,
		Event_Status			= 18,
		Event_DeviceVersion     = 19,
		Event_Image				= 20,
		// Custom
		Event_Status0     		= 21,
		Event_Adc				= 22,
		Event_Max				= 23,
	};



	Qul::Signal<void(int mmsgid)>messageChanged;
	Qul::Signal<void(bool menable)>btMessageChanged;
	Qul::Signal<void(int mkey)>navSwitchStatusChanged;
    Qul::Signal<void(int mid,int mcode)> alertInfoChanged;
	Qul::Signal<void(int mdrive,int mgear)>driveModeChanged;
	Qul::Signal<void(bool menable)>deviceVersionChanged;
	Qul::Signal<void(bool mstatus)>lvStatusChanged;	
	Qul::Signal<void(int mid ,int mstatus)>deviceStatusChanged;
	Qul::Signal<void(int mdir, int mdist,Qul::Private::String smsg)>tbtNavInfoChanged;
	Qul::Signal<void(int msoc,int mrange, int mbattemp,int mbatvoltage,int mbatcurrent)> battInfoChanged;
	Qul::Signal<void(bool mtype,bool mgunlock,int mstatus,int mctime,int mchargedur,int mdischargecycle,int menergycon)> chargeInfoChanged;
    Qul::Signal<void(int mspeed,int mrpm,int modo, int mtripa,int mtripb,int mmotortemp, int mpower)> motorInfoChanged;
	Qul::Signal<void(int mmode,Qul::Private::String mnum,Qul::Private::String mmsg)>callInfoChanged;
	Qul::Signal<void(int mday,int mmonth,int myear,int mhour,int mminute,
					 bool mPM, int medit,int mstate,bool menable)>dateTimeChanged;;
    Qul::Signal<void(bool minput1,bool minput2,bool minput3,bool minput4,bool minput5,bool minput6,bool minput7,bool minput8,bool minput9,bool minput10)>hwStatusChanged;
    Qul::Signal<void(int mindleft,int mindright,int mhighbeam,int mlowbeam,int msidestand,int mdoorlock,
    				 int mparkingmode,int mparkingbrake,bool mhazard,bool mservice)>status0InfoChanged;
    Qul::Signal<void(int mble,int mregen,int mnetwork)>status1InfoChanged;

    void updatePlatform(int eEvent, void* pEventParam);
    void updateUI(int eEvent, void* pEventParam);

private:
    HmiHandler();
    HmiHandler(const HmiHandler &);
    HmiHandler &operator=(const HmiHandler &);
};


#define HMI_EVENT_DATA_SIZE 252U

struct HmiEvent
{
	int command;
	uint8_t sData[HMI_EVENT_DATA_SIZE];
};

class HmiEventQueue : public Qul::Singleton<HmiEventQueue>, public Qul::EventQueue<HmiEvent, Qul::EventQueueOverrunPolicy_Discard, 150>
{
public:
    void onEvent(const HmiEvent &sEvent);

    void onQueueOverrun() override
    {
        clearOverrun();
        iOverrunCount++;
    }

    void onEventDiscarded(HmiEvent * &event)
    {
        (void)event;
        iDiscardCount++;
    }

    uint32_t iOverrunCount = 0U;
    uint32_t iDiscardCount = 0U;
};

namespace UI {
void sendToUI(int eEvent, void* pEventParam);
}

#endif // HMIHANDLER_H
