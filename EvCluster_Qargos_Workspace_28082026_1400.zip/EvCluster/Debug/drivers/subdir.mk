################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/fsl_anatop_ai.c \
../drivers/fsl_cache.c \
../drivers/fsl_clock.c \
../drivers/fsl_common.c \
../drivers/fsl_common_arm.c \
../drivers/fsl_dcdc.c \
../drivers/fsl_elcdif.c \
../drivers/fsl_flexcan.c \
../drivers/fsl_gpc.c \
../drivers/fsl_gpio.c \
../drivers/fsl_gpt.c \
../drivers/fsl_lcdifv2.c \
../drivers/fsl_lpadc.c \
../drivers/fsl_lpi2c.c \
../drivers/fsl_lpi2c_freertos.c \
../drivers/fsl_lpuart.c \
../drivers/fsl_lpuart_freertos.c \
../drivers/fsl_mipi_dsi.c \
../drivers/fsl_pmu.c \
../drivers/fsl_pwm.c \
../drivers/fsl_pxp.c \
../drivers/fsl_romapi.c \
../drivers/fsl_soc_mipi_csi2rx.c \
../drivers/fsl_soc_src.c \
../drivers/fsl_usdhc.c \
../drivers/fsl_xbara.c 

C_DEPS += \
./drivers/fsl_anatop_ai.d \
./drivers/fsl_cache.d \
./drivers/fsl_clock.d \
./drivers/fsl_common.d \
./drivers/fsl_common_arm.d \
./drivers/fsl_dcdc.d \
./drivers/fsl_elcdif.d \
./drivers/fsl_flexcan.d \
./drivers/fsl_gpc.d \
./drivers/fsl_gpio.d \
./drivers/fsl_gpt.d \
./drivers/fsl_lcdifv2.d \
./drivers/fsl_lpadc.d \
./drivers/fsl_lpi2c.d \
./drivers/fsl_lpi2c_freertos.d \
./drivers/fsl_lpuart.d \
./drivers/fsl_lpuart_freertos.d \
./drivers/fsl_mipi_dsi.d \
./drivers/fsl_pmu.d \
./drivers/fsl_pwm.d \
./drivers/fsl_pxp.d \
./drivers/fsl_romapi.d \
./drivers/fsl_soc_mipi_csi2rx.d \
./drivers/fsl_soc_src.d \
./drivers/fsl_usdhc.d \
./drivers/fsl_xbara.d 

OBJS += \
./drivers/fsl_anatop_ai.o \
./drivers/fsl_cache.o \
./drivers/fsl_clock.o \
./drivers/fsl_common.o \
./drivers/fsl_common_arm.o \
./drivers/fsl_dcdc.o \
./drivers/fsl_elcdif.o \
./drivers/fsl_flexcan.o \
./drivers/fsl_gpc.o \
./drivers/fsl_gpio.o \
./drivers/fsl_gpt.o \
./drivers/fsl_lcdifv2.o \
./drivers/fsl_lpadc.o \
./drivers/fsl_lpi2c.o \
./drivers/fsl_lpi2c_freertos.o \
./drivers/fsl_lpuart.o \
./drivers/fsl_lpuart_freertos.o \
./drivers/fsl_mipi_dsi.o \
./drivers/fsl_pmu.o \
./drivers/fsl_pwm.o \
./drivers/fsl_pxp.o \
./drivers/fsl_romapi.o \
./drivers/fsl_soc_mipi_csi2rx.o \
./drivers/fsl_soc_src.o \
./drivers/fsl_usdhc.o \
./drivers/fsl_xbara.o 


# Each subdirectory must supply rules for building sources it contributes
drivers/%.o: ../drivers/%.c drivers/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCLUSTER_PANEL_WIDTH=800 -DCLUSTER_PANEL_HEIGHT=480 -DUDS_SERVICE_ENABLE=0 -DEEPROM=0 -DBLE_ENABLED=0 -DCLUSTER_HW_VERSION=2 -DCLUSTER_DISPLAY_INTERFACE=0 -DCLUSTER_DISPLAY=2 -DCLUSTER_NAVIGATION_SWITCH_ENABLE=1 -DCPU_MIMXRT1176AVM8A -DCPU_MIMXRT1176DVMAA_cm7 -DCPU_MIMXRT1176DVMAA -DCPU_MIMXRT1176AVM8A_cm7 -DSDK_OS_BAREMETAL -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSERIAL_PORT_TYPE_UART=1 -DXIP_BOOT_HEADER_DCD_ENABLE=1 -DXIP_BOOT_HEADER_XMCD_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -DSDK_OS_FREE_RTOS -D__USE_CMSIS -DDEBUG -DCPP_NO_HEAP -DFSL_RTOS_FREE_RTOS -D"PRINTF_ADVANCED_ENABLE =0" -D"PRINTF_FLOAT_ENABLE =0" -D"SCANF_ADVANCED_ENABLE =0" -DSCANF_FLOAT_ENABLE=0 -DSKIP_SYSCLK_INIT -DUSE_SDRAM -DSDK_I2C_BASED_COMPONENT_USED=1 -DENABLE_PWM_CONTROL=0 -DCLUSTER_KEYIGNITION_SUPPORTED=1 -DSDIO_ENABLED -DDATA_SECTION_IS_CACHEABLE=1 -DCUSTOM_VGLITE_MEMORY_CONFIG=0 -DVG_COMMAND_CALL=1 -DVG_TARGET_FAST_CLEAR=0 -DSDK_DEBUGCONSOLE_UART -DDEBUG_CONSOLE_RX_ENABLE=0 -DFSL_SDK_DRIVER_QUICK_ACCESS_ENABLE=1 -DCR_INTEGER_PRINTF -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\board" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\osa" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\controller\hmi\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\opensource\cjson" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\freertos\freertos-kernel\include" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\freertos\freertos-kernel\portable\GCC\ARM_CM4F" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\drivers" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\xip" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\device" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\CMSIS" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\serial_manager" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\uart" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\utilities" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\video" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\lists" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\startup" -I"C:\Qt\QtMCUs\2.5.0\include" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\qoi" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\minihdlc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\common" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\nanopb" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\platform\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos\display" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\vglite\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\vglite\VGLite\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\vglite\VGLiteKernel" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\vglite\VGLiteKernel\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\config" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\controller\hal\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\controller\manager\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\gpio" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\GeneratedHmi\qargos_ui" -O0 -fno-common -g3 -Wall -Wextra -Wconversion -Wcast-align -Wcast-qual -Wdisabled-optimization -Wlogical-op -Wmissing-declarations -Wredundant-decls -Wshadow -Wsign-conversion -Wswitch-default -Wundef -Wfloat-equal -c -ffunction-sections -fdata-sections -ffreestanding -fno-builtin -imacros "D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\New folder\EvCluster_Qargos_Workspace_17082026_1848\EvCluster\source\wifi_config.h" -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-drivers

clean-drivers:
	-$(RM) ./drivers/fsl_anatop_ai.d ./drivers/fsl_anatop_ai.o ./drivers/fsl_cache.d ./drivers/fsl_cache.o ./drivers/fsl_clock.d ./drivers/fsl_clock.o ./drivers/fsl_common.d ./drivers/fsl_common.o ./drivers/fsl_common_arm.d ./drivers/fsl_common_arm.o ./drivers/fsl_dcdc.d ./drivers/fsl_dcdc.o ./drivers/fsl_elcdif.d ./drivers/fsl_elcdif.o ./drivers/fsl_flexcan.d ./drivers/fsl_flexcan.o ./drivers/fsl_gpc.d ./drivers/fsl_gpc.o ./drivers/fsl_gpio.d ./drivers/fsl_gpio.o ./drivers/fsl_gpt.d ./drivers/fsl_gpt.o ./drivers/fsl_lcdifv2.d ./drivers/fsl_lcdifv2.o ./drivers/fsl_lpadc.d ./drivers/fsl_lpadc.o ./drivers/fsl_lpi2c.d ./drivers/fsl_lpi2c.o ./drivers/fsl_lpi2c_freertos.d ./drivers/fsl_lpi2c_freertos.o ./drivers/fsl_lpuart.d ./drivers/fsl_lpuart.o ./drivers/fsl_lpuart_freertos.d ./drivers/fsl_lpuart_freertos.o ./drivers/fsl_mipi_dsi.d ./drivers/fsl_mipi_dsi.o ./drivers/fsl_pmu.d ./drivers/fsl_pmu.o ./drivers/fsl_pwm.d ./drivers/fsl_pwm.o ./drivers/fsl_pxp.d ./drivers/fsl_pxp.o ./drivers/fsl_romapi.d ./drivers/fsl_romapi.o ./drivers/fsl_soc_mipi_csi2rx.d ./drivers/fsl_soc_mipi_csi2rx.o ./drivers/fsl_soc_src.d ./drivers/fsl_soc_src.o ./drivers/fsl_usdhc.d ./drivers/fsl_usdhc.o ./drivers/fsl_xbara.d ./drivers/fsl_xbara.o

.PHONY: clean-drivers

