/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_hal_buzzer.c							   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------*
 * Include Headers
 *-----------------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "fsl_pwm.h"
#include "fsl_xbara.h"
#include "cluster_common.h"
#include "cluster_controller_hal_buzzer.h"
#include "cluster_controller_hal.h"

/*----------------------------------------------------------------------------*
 * Macro ,Structure and ENUM definition
 *----------------------------------------------------------------------------*/
#define BUZZER_PWM_SRC_CLK_FREQ      CLOCK_GetRootClockFreq(kCLOCK_Root_Bus)
#define BUZZER_PWM_CLOCK_DIVIDER     kPWM_Prescale_Divide_128
#define BUZZER_PWM_SUBMODULE         kPWM_Module_2
#define BUZZER_PWM_MODULE_CONTROL    kPWM_Control_Module_2
#define BUZZER_PWM_CHANNEL           kPWM_PwmA
#define BUZZER_PWM_MODE              kPWM_SignedCenterAligned
#define BUZZER_PWM_NO_OF_CHANNELS    1

#define BUZZER_PWM_FREQUENCY         50
#define BUZZER_DUTY_ON               100
#define BUZZER_DUTY_OFF              0
#define BUZZER_QUEUE_SIZE            16
#define BUZZER_SEND_TIMEOUT_MS       100U
#define BUZZER_DEFAULT_PERIOD_MS     500U

typedef struct
{
	bool bEnable;
	bool bIsContinuous;
	uint32_t  iFrequency;
	uint32_t  iDuration;
	uint32_t  iBeepCount;
} sBuzParams_t;

typedef struct
{
	bool        bIsActive;
	bool        bIsContinuous;
	int32_t     iIsInitialised;
	PWM_Type    *pBase;
	QueueHandle_t qCmd;
	TaskHandle_t  hTask;
	sBuzParams_t  sStatus;
	sBuzParams_t  sNewStatus;
	sBuzParams_t  prevStatus;
} sBuzzer_t;
/*----------------------------------------------------------------------------*
 * Static and global variaCan definition	                         		  *
 *----------------------------------------------------------------------------*/
static sBuzzer_t hBuzzer = {0};
/*----------------------------------------------------------------------------*
 * Local function definition	                         				      *
 *----------------------------------------------------------------------------*/
static int32_t Buzzer_Pwm_Init(sBuzzer_t *pHan);
static void Buzzer_Task(void *pvParameters);
static void Buzzer_SetState(sBuzzer_t *pHan ,bool benable);
static int32_t Buzzer_UpdateMode(sBuzzer_t *pHan,sBuzParams_t * pParams);
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Hal_Buzzer_Init	    	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Buzzer_Init(void)
{
	int32_t iRVal = BCU_OK;
	if(hBuzzer.iIsInitialised == 0)
	{
		memset(&hBuzzer,0,sizeof(sBuzzer_t));

		iRVal = Buzzer_Pwm_Init(&hBuzzer);
		if(iRVal == BCU_OK)
		{
			hBuzzer.qCmd = xQueueCreate(BUZZER_QUEUE_SIZE,sizeof(sBuzParams_t));
			if (hBuzzer.qCmd != NULL)
			{
				BaseType_t xReturn = xTaskCreate(Buzzer_Task,"BuzzerTask",
						configMINIMAL_STACK_SIZE + 200,
						&hBuzzer,
						CLUSTER_TASK_PRIORITY_DATA,
						&hBuzzer.hTask);

				if (xReturn == pdPASS)
				{
					hBuzzer.iIsInitialised = 1;
				}
				else
				{
					vQueueDelete(hBuzzer.qCmd);
					hBuzzer.qCmd = NULL;
					iRVal = BCU_NOK;
				}
			}
			else
			{
				iRVal = BCU_NOK;
			}
		}
	}

	return iRVal;
}
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Hal_Buzzer_DeInit    	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Buzzer_DeInit(void)
{
	if(hBuzzer.iIsInitialised == 1)
	{
		if (hBuzzer.hTask != NULL)
		{
			vTaskDelete(hBuzzer.hTask);
			hBuzzer.hTask = NULL;
		}

		if (hBuzzer.qCmd != NULL)
		{
			vQueueDelete(hBuzzer.qCmd);
			hBuzzer.qCmd = NULL;
		}

		if(hBuzzer.pBase != NULL)
		{
			Buzzer_SetState(&hBuzzer,false);

			PWM_StopTimer(hBuzzer.pBase, BUZZER_PWM_MODULE_CONTROL);
			PWM_Deinit(hBuzzer.pBase, BUZZER_PWM_SUBMODULE);
		}

		memset(&hBuzzer,0,sizeof(sBuzzer_t));
	}
	return BCU_OK;
}
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Hal_Buzzer_Enable    	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Buzzer_Enable(bool bEnable,bool bcontinuous,uint32_t iDuration,uint32_t iBeepCount)
{
	int32_t iRval = BCU_OK;
	sBuzParams_t sParams = {0};

	if ((hBuzzer.iIsInitialised == 1) && (hBuzzer.qCmd != NULL))
	{
		sParams.bEnable = bEnable;
		sParams.bIsContinuous = bcontinuous;
		sParams.iDuration = iDuration;
		sParams.iBeepCount = iBeepCount;
		Buzzer_UpdateMode(&hBuzzer,&sParams);
	}
	return iRval;
}
static int32_t Buzzer_UpdateMode(sBuzzer_t *pHan, sBuzParams_t *pParams)
{
	if ((pHan == NULL) || (pHan->qCmd == NULL) || (pParams == NULL))
	{
		return BCU_NOK;
	}
	if(pParams->bEnable)
	{
		if(pParams->bIsContinuous)
		{
			if (xQueueSend(pHan->qCmd,pParams,pdMS_TO_TICKS(BUZZER_SEND_TIMEOUT_MS)) == pdPASS)
			{
				pHan->prevStatus.bIsContinuous = 1;
				return BCU_OK;
			}
			else
			{
				return BCU_NOK;
			}
		}
		else if(pHan->prevStatus.bIsContinuous != 1 )
		{
			if (xQueueSend(pHan->qCmd,pParams,pdMS_TO_TICKS(BUZZER_SEND_TIMEOUT_MS)) == pdPASS)
			{
				pHan->prevStatus.bIsContinuous = 0;
				return BCU_OK;
			}
			else
			{
				return BCU_NOK;
			}
		}
	}
	else // Disable buzzer
	{
		if (xQueueSend(pHan->qCmd, pParams, pdMS_TO_TICKS(BUZZER_SEND_TIMEOUT_MS)) == pdPASS)
		{
			pHan->prevStatus.bIsContinuous = 0;
			return BCU_OK;
		}
		else
		{
			return BCU_NOK;
		}
	}
	return BCU_NOK;
}
//static int32_t Buzzer_UpdateMode(sBuzzer_t *pHan, sBuzParams_t *pParams)
//{
//    if ((pHan == NULL) || (pHan->qCmd == NULL) || (pParams == NULL))
//    {
//        return BCU_NOK;
//    }
//
//    if (xQueueSend(pHan->qCmd,
//                   pParams,
//                   pdMS_TO_TICKS(BUZZER_SEND_TIMEOUT_MS)) == pdPASS)
//    {
//        return BCU_OK;
//    }
//
//    return BCU_NOK;
//}
/*----------------------------------------------------------------------------*
 * Function	    :		Buzzer_Task							    	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void Buzzer_Task(void *pvParameters)
{
	sBuzzer_t *pHan = (sBuzzer_t*)pvParameters;
	sBuzParams_t sParams = {0};
	TickType_t pTimeout = portMAX_DELAY;

	bool bOn = false;
	uint32_t iBeepCount = 0;

	while (1)
	{
		if (xQueueReceive(pHan->qCmd, &sParams, pTimeout) == pdPASS)
		{
			if (sParams.bEnable)
			{
				pHan->sStatus.bEnable       = true;
				pHan->sStatus.iDuration     = sParams.iDuration;
				pHan->sStatus.iBeepCount    = sParams.iBeepCount;
				pHan->sStatus.bIsContinuous = sParams.bIsContinuous;

				iBeepCount = 0;
				bOn = false;

				if (sParams.bIsContinuous && sParams.iDuration == 0U)
				{
					Buzzer_SetState(pHan, true);
					pTimeout = portMAX_DELAY;
				}
				else
				{
					if (sParams.iDuration > 0U)
					{
						pTimeout = pdMS_TO_TICKS(sParams.iDuration);
					}
					else
					{
						pTimeout = portMAX_DELAY;
					}
				}
			}
			else
			{
				Buzzer_SetState(pHan, false);

				pHan->sStatus.bEnable       = false;
				pHan->sStatus.bIsContinuous = false;
				pHan->sStatus.iDuration     = 0;

				iBeepCount = 0;
				bOn = false;

				pTimeout = portMAX_DELAY;
			}
		}
		else
		{
			if (!pHan->sStatus.bEnable)
			{
				Buzzer_SetState(pHan, false);
				pTimeout = portMAX_DELAY;
				continue;
			}
			bOn = !bOn;

			if (pHan->sStatus.bIsContinuous == false)
			{
				if (bOn)
				{
					iBeepCount++;

					if (iBeepCount > pHan->sStatus.iBeepCount)
					{
						Buzzer_SetState(pHan, false);

						pHan->sStatus.bEnable       = false;
						pHan->sStatus.bIsContinuous = false;
						pHan->sStatus.iDuration     = 0;

						iBeepCount = 0;
						bOn = false;

						pTimeout = portMAX_DELAY;
						continue;
					}
				}
			}

			if (pHan->sStatus.bEnable)
			{
				Buzzer_SetState(pHan, bOn);

				pTimeout = pdMS_TO_TICKS(pHan->sStatus.iDuration);
			}
			else
			{
				Buzzer_SetState(pHan, false);
				pTimeout = portMAX_DELAY;
			}
		}
	}
}/*----------------------------------------------------------------------------*
 * Function	    :		Buzzer_SetState						    	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void Buzzer_SetState(sBuzzer_t *pHan ,bool benable)
{
	if ((pHan->iIsInitialised) && (pHan->pBase != NULL))
	{
		if(benable)
		{
			PWM_OutputEnable(pHan->pBase,BUZZER_PWM_CHANNEL,BUZZER_PWM_SUBMODULE);
		}
		else
		{
			PWM_OutputDisable(pHan->pBase,BUZZER_PWM_CHANNEL,BUZZER_PWM_SUBMODULE);
		}

		PWM_SetPwmLdok(pHan->pBase, BUZZER_PWM_MODULE_CONTROL, true);
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_CanProc_Init    	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static int32_t Buzzer_Pwm_Init(sBuzzer_t *pHan)
{
	pwm_config_t pwmConfig;
	pwm_fault_param_t faultConfig;
	pwm_signal_param_t pwmSignal;
	uint16_t deadTimeVal;

	pHan->pBase = PWM1;

	XBARA_Init(XBARA1);
	XBARA_SetSignalsConnection(XBARA1,
			kXBARA1_InputLogicHigh,
			kXBARA1_OutputFlexpwm1234Fault2);

	PWM_GetDefaultConfig(&pwmConfig);
	pwmConfig.prescale = BUZZER_PWM_CLOCK_DIVIDER;
	pwmConfig.reloadLogic = kPWM_ReloadPwmFullCycle;
	pwmConfig.pairOperation = kPWM_Independent;
	pwmConfig.enableDebugMode = true;

	if(PWM_Init(pHan->pBase,BUZZER_PWM_SUBMODULE,&pwmConfig) != kStatus_Success)
		return BCU_NOK;

	PWM_FaultDefaultConfig(&faultConfig);
	PWM_SetupFaults(pHan->pBase,kPWM_Fault_2,&faultConfig);

	PWM_SetupFaultDisableMap(pHan->pBase,
			BUZZER_PWM_SUBMODULE,
			BUZZER_PWM_CHANNEL,
			kPWM_faultchannel_0,
			kPWM_FaultDisable_2);

	deadTimeVal = (uint16_t)(((uint64_t)BUZZER_PWM_SRC_CLK_FREQ * 650) / 1000000000);

	pwmSignal.pwmChannel = BUZZER_PWM_CHANNEL;
	pwmSignal.level = kPWM_HighTrue;
	pwmSignal.dutyCyclePercent = BUZZER_DUTY_ON;
	pwmSignal.deadtimeValue = deadTimeVal;
	pwmSignal.faultState = kPWM_PwmFaultState0;
	pwmSignal.pwmchannelenable = true;

	if(PWM_SetupPwm(pHan->pBase,
			BUZZER_PWM_SUBMODULE,
			&pwmSignal,
			BUZZER_PWM_NO_OF_CHANNELS,
			BUZZER_PWM_MODE,
			BUZZER_PWM_FREQUENCY,
			BUZZER_PWM_SRC_CLK_FREQ) != kStatus_Success)
		return BCU_NOK;

	PWM_SetPwmLdok(pHan->pBase,BUZZER_PWM_MODULE_CONTROL,true);
	PWM_StartTimer(pHan->pBase,BUZZER_PWM_MODULE_CONTROL);

	PWM_OutputDisable(pHan->pBase,
			BUZZER_PWM_CHANNEL,
			BUZZER_PWM_SUBMODULE);

	return BCU_OK;
}
