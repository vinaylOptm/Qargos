################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_cache.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_context.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_devicelink.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_drawing.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_layers.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_memory.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_rng.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_serial_console.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_touch.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/vglitedrawingengine.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/vgliterotationcache.cpp \
../platform/boards/nxp/mimxrt1170-evk-freertos/vglitesupport.cpp 

C_SRCS += \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_clock.c \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_init.c \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_irq.c \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_power.c \
../platform/boards/nxp/mimxrt1170-evk-freertos/platform_time.c 

CPP_DEPS += \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_cache.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_context.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_devicelink.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_drawing.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_layers.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_memory.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_rng.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_serial_console.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_touch.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/vglitedrawingengine.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/vgliterotationcache.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/vglitesupport.d 

C_DEPS += \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_clock.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_init.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_irq.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_power.d \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_time.d 

OBJS += \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_cache.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_clock.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_context.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_devicelink.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_drawing.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_init.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_irq.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_layers.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_memory.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_power.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_rng.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_serial_console.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_time.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/platform_touch.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/vglitedrawingengine.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/vgliterotationcache.o \
./platform/boards/nxp/mimxrt1170-evk-freertos/vglitesupport.o 


# Each subdirectory must supply rules for building sources it contributes
platform/boards/nxp/mimxrt1170-evk-freertos/%.o: ../platform/boards/nxp/mimxrt1170-evk-freertos/%.cpp platform/boards/nxp/mimxrt1170-evk-freertos/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C++ Compiler'
	arm-none-eabi-c++ -std=gnu++14 -DCPU_MIMXRT1176AVM8A -DCLUSTER_PANEL_WIDTH=800 -DCLUSTER_PANEL_HEIGHT=480 -DCLUSTER_KEYIGNITION_SUPPORTED=1 -DUDS_SERVICE_ENABLE=0 -DEEPROM=0 -DBLE_ENABLED=0 -DCLUSTER_HW_VERSION=2 -DCLUSTER_DISPLAY=2 -DCLUSTER_DISPLAY_INTERFACE=0 -DCLUSTER_NAVIGATION_SWITCH_ENABLE=1 -DCPU_MIMXRT1176AVM8A_cm7 -DCPU_MIMXRT1176DVMAA -DCPU_MIMXRT1176DVMAA_cm7 -DCPU_MIMXRT1062DVL6A_cm7 -DSDK_OS_BAREMETAL -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSERIAL_PORT_TYPE_UART=1 -DXIP_BOOT_HEADER_DCD_ENABLE=1 -DXIP_BOOT_HEADER_XMCD_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -DSDK_OS_FREE_RTOS -D__USE_CMSIS -DDEBUG -D__NEWLIB__ -DCPP_NO_HEAP -DFSL_RTOS_FREE_RTOS -D"PRINTF_ADVANCED_ENABLE =0" -D"PRINTF_FLOAT_ENABLE =0" -D"SCANF_ADVANCED_ENABLE =0" -DSCANF_FLOAT_ENABLE=0 -DSKIP_SYSCLK_INIT -DUSE_SDRAM -DSDK_I2C_BASED_COMPONENT_USED=1 -DVGLITE_POINT_FILTERING_FOR_SIMPLE_SCALE -DQUL_STD_STRING_SUPPORT -DENABLE_PWM_CONTROL=0 -DSDIO_ENABLED -DDATA_SECTION_IS_CACHEABLE=1 -DCUSTOM_VGLITE_MEMORY_CONFIG=0 -DVG_COMMAND_CALL=1 -DVG_TARGET_FAST_CLEAR=0 -DSDK_DEBUGCONSOLE_UART -DDEBUG_CONSOLE_RX_ENABLE=0 -DFSL_SDK_DRIVER_QUICK_ACCESS_ENABLE=1 -DCR_INTEGER_PRINTF -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\GeneratedHmi\qargos_ui" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\board" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\osa" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\plf\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\freertos\freertos-kernel\include" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\freertos\freertos-kernel\portable\GCC\ARM_CM4F" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\drivers" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\xip" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\device" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\CMSIS" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\serial_manager" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\uart" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\utilities" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\video" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\lists" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\startup" -I"C:\Qt\QtMCUs\2.5.0\include" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\qoi" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\minihdlc" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\nanopb" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos\display" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLite\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLiteKernel" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLiteKernel\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\config" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\hal\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\manager\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\hmi\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\gpio" -O0 -fno-common -g3 -Wall -c -ffunction-sections -fdata-sections -ffreestanding -fno-builtin -fno-rtti -fno-exceptions -imacros "D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\source\wifi_config.h" -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

platform/boards/nxp/mimxrt1170-evk-freertos/%.o: ../platform/boards/nxp/mimxrt1170-evk-freertos/%.c platform/boards/nxp/mimxrt1170-evk-freertos/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCLUSTER_PANEL_WIDTH=800 -DCLUSTER_PANEL_HEIGHT=480 -DUDS_SERVICE_ENABLE=0 -DEEPROM=0 -DBLE_ENABLED=0 -DCLUSTER_HW_VERSION=2 -DCLUSTER_DISPLAY_INTERFACE=0 -DCLUSTER_DISPLAY=2 -DCLUSTER_NAVIGATION_SWITCH_ENABLE=1 -DCPU_MIMXRT1176AVM8A -DCPU_MIMXRT1176DVMAA_cm7 -DCPU_MIMXRT1176DVMAA -DCPU_MIMXRT1176AVM8A_cm7 -DSDK_OS_BAREMETAL -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSERIAL_PORT_TYPE_UART=1 -DXIP_BOOT_HEADER_DCD_ENABLE=1 -DXIP_BOOT_HEADER_XMCD_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -DSDK_OS_FREE_RTOS -D__USE_CMSIS -DDEBUG -DCPP_NO_HEAP -DFSL_RTOS_FREE_RTOS -D"PRINTF_ADVANCED_ENABLE =0" -D"PRINTF_FLOAT_ENABLE =0" -D"SCANF_ADVANCED_ENABLE =0" -DSCANF_FLOAT_ENABLE=0 -DSKIP_SYSCLK_INIT -DUSE_SDRAM -DSDK_I2C_BASED_COMPONENT_USED=1 -DENABLE_PWM_CONTROL=0 -DCLUSTER_KEYIGNITION_SUPPORTED=1 -DSDIO_ENABLED -DDATA_SECTION_IS_CACHEABLE=1 -DCUSTOM_VGLITE_MEMORY_CONFIG=0 -DVG_COMMAND_CALL=1 -DVG_TARGET_FAST_CLEAR=0 -DSDK_DEBUGCONSOLE_UART -DDEBUG_CONSOLE_RX_ENABLE=0 -DFSL_SDK_DRIVER_QUICK_ACCESS_ENABLE=1 -DCR_INTEGER_PRINTF -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\board" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\osa" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\hmi\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\opensource\cjson" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\freertos\freertos-kernel\include" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\freertos\freertos-kernel\portable\GCC\ARM_CM4F" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\drivers" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\xip" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\device" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\CMSIS" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\serial_manager" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\uart" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\utilities" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\video" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\lists" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\startup" -I"C:\Qt\QtMCUs\2.5.0\include" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\qoi" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\minihdlc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\common" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\nanopb" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos\display" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLite\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLiteKernel" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\vglite\VGLiteKernel\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\config" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\hal\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\cluster\controller\manager\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\component\gpio" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\GeneratedHmi\qargos_ui" -O0 -fno-common -g3 -Wall -Wextra -Wconversion -Wcast-align -Wcast-qual -Wdisabled-optimization -Wlogical-op -Wmissing-declarations -Wredundant-decls -Wshadow -Wsign-conversion -Wswitch-default -Wundef -Wfloat-equal -c -ffunction-sections -fdata-sections -ffreestanding -fno-builtin -imacros "D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_17062026\EvCluster_Qargos_Workspace\EvCluster\source\wifi_config.h" -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-platform-2f-boards-2f-nxp-2f-mimxrt1170-2d-evk-2d-freertos

clean-platform-2f-boards-2f-nxp-2f-mimxrt1170-2d-evk-2d-freertos:
	-$(RM) ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_cache.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_cache.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_clock.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_clock.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_context.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_context.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_devicelink.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_devicelink.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_drawing.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_drawing.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_init.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_init.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_irq.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_irq.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_layers.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_layers.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_memory.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_memory.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_power.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_power.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_rng.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_rng.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_serial_console.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_serial_console.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_time.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_time.o ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_touch.d ./platform/boards/nxp/mimxrt1170-evk-freertos/platform_touch.o ./platform/boards/nxp/mimxrt1170-evk-freertos/vglitedrawingengine.d ./platform/boards/nxp/mimxrt1170-evk-freertos/vglitedrawingengine.o ./platform/boards/nxp/mimxrt1170-evk-freertos/vgliterotationcache.d ./platform/boards/nxp/mimxrt1170-evk-freertos/vgliterotationcache.o ./platform/boards/nxp/mimxrt1170-evk-freertos/vglitesupport.d ./platform/boards/nxp/mimxrt1170-evk-freertos/vglitesupport.o

.PHONY: clean-platform-2f-boards-2f-nxp-2f-mimxrt1170-2d-evk-2d-freertos

