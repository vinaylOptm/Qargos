/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_manager_systeminfo.c 							   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
#include "fsl_debug_console.h"
#include "cluster_common.h"
#include "semphr.h"
#include "cluster_controller_manager_systeminfo.h"
#include "cluster_controller_hal.h"
/*----------------------------------------------------------------------------*
 * Macro ,Structure and Enum definition                   				      *
 *----------------------------------------------------------------------------*/
#define MAX_QUEUE_MSG_COUNT				 4
#define MSG_BUFFER_SIZE					 sizeof(sMessage_t)
#define MSG_QUEUE_BUFFER_SIZE 			 (MSG_BUFFER_SIZE + 16)
#define CORRUPTED_SECTOR0                1
#define CORRUPTED_SECTOR1                2
#define CORRUPTED_SECTORALL              4
/* Max time to wait for the flash mutex: covers erase (200ms) + write (50ms) + margin */
#define SYSINFO_SEMA_TIMEOUT             pdMS_TO_TICKS(500)

typedef struct
{
	uint8_t    	    iDTCStatus;
	uint8_t         iReadFlag;
	uint8_t    	    iCurSector;
	uint32_t    	iIsInitialised;
	uint32_t        iCorruptedSector;
	QueueHandle_t     qRxMsg;
	sDeviceInfo_t      sProductInfo;
	sClusterInfo_t     sInfoCache;
	SemaphoreHandle_t  pSysSema;
	TaskHandle_t       hSysInfoThread;
	sClusterInfo_t  	  sMemCache[2];
	sChargeAlert_t        sChargeAlert;
}sSysInfo_t;

/*----------------------------------------------------------------------------*
 * Static and global variable definition	                         		  *
 *----------------------------------------------------------------------------*/
static sSysInfo_t hConfig = {0};

static void SysInfo_ModeHandler(void *arg);
static int32_t SystemInfo_GetDTCInfo(sSysInfo_t * pHan);
static int32_t SystemInfo_GetClusterData(sSysInfo_t * pHan);
static int32_t SystemInfo_GetChargeStatus(sSysInfo_t * pHan);
static int32_t SystemInfo_GetVehicleSpecInfo(sSysInfo_t * pHan);
static int32_t SystemInfo_ReadClusterData(sClusterInfo_t * pCache, uint32_t iSector);
static void SystemInfo_HandleCorruptSectors(sSysInfo_t *pHan, int iMemSec0Cur, int iMemSec1Cur);
static int32_t SystemInfo_FlashWriteData(sSysInfo_t *pHan, uint32_t iSectorAddr,sClusterInfo_t *sInfoCache);
static int32_t SystemInfo_UpdateClusterData(sSysInfo_t * pHan ,sClusterInfo_t* pData, uint32_t iParam,uint32_t iSectorAddr);
/*-----------------------------------------------------------------------------*
 * Function	    : 	Cluster_Controller_Manager_SystemInfo_Init				*
 * Params	        :	void			        		                        *
 * Return value	:	On success return BCU_OK else return BCU_NOK            *
 * Description  	:	In this function initializes the sSysInfo_t and creates
 * 					xSemaphoreCreateBinary to synchronize the read and write
 * 					operation. And Read the data from secondary flash for re
 * 					-ference						                        *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_Init(void)
{
	int32_t iRval = BCU_NOK;
	uint16_t iStackSize = 0;

	if(hConfig.iIsInitialised != 0)
	{
		return BCU_OK;
	}

	memset(&hConfig, 0 ,sizeof(sSysInfo_t));

		hConfig.pSysSema = xSemaphoreCreateBinary();

		Cluster_Controller_Hal_ConfigGetStackSize(&iStackSize);

		hConfig.qRxMsg = xQueueCreate(MAX_QUEUE_MSG_COUNT,MSG_QUEUE_BUFFER_SIZE);

	if((hConfig.pSysSema != NULL) && (hConfig.qRxMsg != NULL))
	{
		xSemaphoreGive(hConfig.pSysSema);
		if (xTaskCreate(SysInfo_ModeHandler, "SysInfo", iStackSize, &hConfig,
				configMAX_PRIORITIES - 2, &hConfig.hSysInfoThread) == pdPASS)
		{
			hConfig.iIsInitialised = 1;
			SystemInfo_GetClusterData(&hConfig);
			iRval = BCU_OK;
		}
		else
		{
			PRINTF("\r\nError: SystemInfo xTaskCreate failed\r\n");
			vSemaphoreDelete(hConfig.pSysSema);
			hConfig.pSysSema = NULL;
			vQueueDelete(hConfig.qRxMsg);
			hConfig.qRxMsg = NULL;
		}
	}
	else
	{
		PRINTF("\r\nError: SystemInfo semaphore or queue creation failed\r\n");
		if(hConfig.pSysSema != NULL) { vSemaphoreDelete(hConfig.pSysSema); hConfig.pSysSema = NULL; }
		if(hConfig.qRxMsg  != NULL) { vQueueDelete(hConfig.qRxMsg);        hConfig.qRxMsg  = NULL; }
	}
	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	    : 	Cluster_Controller_Manager_SystemInfo_DeInit			   *
 * Params	        :	void			        		                       *
 * Return value	:	On success return BCU_OK else return BCU_NOK               *
 * Description  	:	In this function Deinitializes the sSysInfo_t and delete
 * 					vSemaphore which is created in initialization.			   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_DeInit(void)
{
	int32_t iRval = BCU_OK;

	if (hConfig.iIsInitialised != 0)
	{
		/* Block new callers from entering semaphore-protected sections */
		hConfig.iIsInitialised = 0;

		if (hConfig.pSysSema != NULL)
		{
			/* Wait for any in-progress operation to release the semaphore,
			 * then hold it so no further operations can proceed */
			xSemaphoreTake(hConfig.pSysSema, portMAX_DELAY);
		}

		/* Task cannot take the semaphore (we hold it) � safe to delete */
		if (hConfig.hSysInfoThread != NULL)
		{
			vTaskDelete(hConfig.hSysInfoThread);
			hConfig.hSysInfoThread = NULL;
		}

		/* We hold the semaphore and the task is gone � safe to delete */
		if (hConfig.pSysSema != NULL)
		{
			vSemaphoreDelete(hConfig.pSysSema);
			hConfig.pSysSema = NULL;
		}

		if (hConfig.qRxMsg != NULL)
		{
			vQueueDelete(hConfig.qRxMsg);
			hConfig.qRxMsg = NULL;
		}

		memset(&hConfig, 0, sizeof(sSysInfo_t));
	}

	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	    : 	Cluster_Controller_Manager_SystemInfo_UpdateInfo		   *
 * Params	    :	sClusterInfo_t* pData and int32_t iValue			       *
 * Return value	:	On success return BCU_OK else return BCU_NOK               *
 * Description  :	In this function,Write the data to secondary flash(Nvm)    *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_UpdateInfo(sClusterInfo_t* pData, uint32_t iMode)
{
	int32_t iRtVal = BCU_NOK;

	if((pData != NULL) && (hConfig.iIsInitialised != 0))
	{

        if(hConfig.iCorruptedSector == CORRUPTED_SECTOR0)
        {
        	/* Sector 0 was corrupted and recovered; next write alternates to sector 1 */
        	hConfig.iCurSector = 1;
        }
        else if(hConfig.iCorruptedSector == CORRUPTED_SECTOR1)
        {
        	/* Sector 1 was corrupted and recovered; next write alternates to sector 0 */
        	hConfig.iCurSector = 0;
        }
        else
        {
        	if(hConfig.iCorruptedSector == CORRUPTED_SECTORALL)
			{
				PRINTF("\r\nThe Device is New or NVM sec0 & sec1 is Corrupted\r\n");
			}
        }

		if(hConfig.iCurSector == 0)
		{
			PRINTF("In SysInfo Saved data: Odo : %d TripA : %d TripB : %d, MemSector: %d \r\n", pData->iOdoVal, pData->iCurTripA, pData->iCurTripB, hConfig.iCurSector);

			uint32_t iSectorAddr = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC0);
			iRtVal = SystemInfo_UpdateClusterData(&hConfig,pData,iMode,iSectorAddr);

			if(iRtVal == BCU_OK)
			{
				hConfig.iCurSector = 1;
				hConfig.iCorruptedSector = 0;
			}
		}
		else
		{
			PRINTF("In SysInfo Saved data: Odo : %d TripA : %d TripB : %d, MemSector: %d \r\n", pData->iOdoVal, pData->iCurTripA, pData->iCurTripB, hConfig.iCurSector);
			uint32_t iSectorAddr = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC1);
			iRtVal = SystemInfo_UpdateClusterData(&hConfig,pData,iMode,iSectorAddr);

			if(iRtVal == BCU_OK)
			{
				hConfig.iCurSector = 0;
				hConfig.iCorruptedSector = 0;
			}
		}
	}
	return iRtVal;
}
/*-----------------------------------------------------------------------------*
 * Function	    : 	Cluster_Controller_Manager_SystemInfo_GetInfo    			*
 * Params	        :	sClusterInfo_t* pData		       						*
 * Return value	:	On success return BCU_OK else return BCU_NOK            *
 * Description  	:	In this function,Read the data to secondary flash(Nvm)  *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_GetInfo(sClusterInfo_t* pData)
{
	int32_t iRval = BCU_NOK;

	if((pData != NULL) && (hConfig.iIsInitialised != 0))
	{
		memcpy(pData,&(hConfig.sInfoCache),sizeof(sClusterInfo_t));
		iRval = BCU_OK;
	}

	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_UpdateProductInfo(uint64_t iInfo, uint32_t iSectorAddr)
{
	int32_t iRval = BCU_NOK;

	if(hConfig.iIsInitialised == 0)
	{
		return BCU_NOK;
	}

	if(xSemaphoreTake(hConfig.pSysSema, SYSINFO_SEMA_TIMEOUT) == pdTRUE)
	{
		uint8_t sBuf[sizeof(iInfo)] = {0};
#if !EEPROM
		Cluster_Controller_Hal_FlashErase(iSectorAddr);
#endif
		memcpy(sBuf,(uint8_t*)&iInfo,sizeof(iInfo));

		uint32_t iSize = sizeof(iInfo);

		iRval = Cluster_Controller_Hal_FlashWriteData(&sBuf[0],iSize ,iSectorAddr);

		xSemaphoreGive(hConfig.pSysSema);
	}

	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_UpdateChargeStatus(sChargeAlert_t *pChargeInfo)
{
	int32_t iRval = BCU_NOK;

	if ((pChargeInfo == NULL) || (hConfig.iIsInitialised == 0))
	{
		return BCU_NOK;
	}

	if (xSemaphoreTake(hConfig.pSysSema, SYSINFO_SEMA_TIMEOUT) == pdTRUE)
	{
		uint8_t sBuf[sizeof(sChargeAlert_t)] = {0};
		uint32_t iSectorAddr = Cluster_Controller_Hal_ConfigGetFlashAddress(VEHICLE_CHARGESTATE_INFO);
#if !EEPROM
		Cluster_Controller_Hal_FlashErase(iSectorAddr);
#endif
		memcpy(sBuf, (uint8_t*)pChargeInfo, sizeof(sChargeAlert_t));

		iRval = Cluster_Controller_Hal_FlashWriteData(&sBuf[0], sizeof(sChargeAlert_t), iSectorAddr);

		xSemaphoreGive(hConfig.pSysSema);
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_GetChargeStatus(sChargeAlert_t *pChargeInfo)
{
    int32_t iRval = BCU_NOK;

    if ((pChargeInfo != NULL) &&( hConfig.iIsInitialised != 0))
	{
    	memcpy(pChargeInfo,&(hConfig.sChargeAlert),sizeof(sChargeAlert_t));
		if((hConfig.sChargeAlert.iStatus == 0) &&
		   (hConfig.sChargeAlert.iSocVal == 0)&&
		   (hConfig.sChargeAlert.iTime == 0))
		{
			PRINTF("\r\nCharge status data not available yet, or Please try again.\r\n");
		}
		else
		{
			iRval = BCU_OK;
		}
	}
    return iRval;
}
 /*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_SetSystemInfo(sClusterInfo_t* pData,uint32_t iMode)
{
	int32_t iRval = BCU_NOK;

	if((pData != NULL) && (hConfig.iIsInitialised != 0))
	{
		// to do
		if(iMode == eSpeedInfo)
		{
			return BCU_NOK;
		}
		iRval = SystemInfo_UpdateClusterData(&hConfig,pData,iMode,0);
	}

	return iRval;
}

/*-----------------------------------------------------------------------------*
 * Function	   	 	: Cluster_Controller_Manager_SystemInfo_SetVehicleSpecInfo*
 * Params	        :	  											  		   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_SetVehicleSpecInfo(void * pData, int32_t iParam)
{
	if(hConfig.iIsInitialised == 0)
	{
		return BCU_NOK;
	}

	if(xSemaphoreTake(hConfig.pSysSema, SYSINFO_SEMA_TIMEOUT) == pdTRUE)
	{
		int32_t iRval = BCU_NOK;
		bool iIsvalid = true;
		switch(iParam)
		{
			case eProductInfo:
			{
				if(pData == NULL) { xSemaphoreGive(hConfig.pSysSema); return BCU_NOK; }
				memcpy(&(hConfig.sProductInfo),(sDeviceInfo_t *)pData,sizeof(sDeviceInfo_t));
			}
			break;
			case eDTCInfo:
			{
				uint8_t iDtcInfo = 0;
				uint8_t iDtcBuf[sizeof(hConfig.iDTCStatus)] = {0};

				if(pData == NULL) { xSemaphoreGive(hConfig.pSysSema); return BCU_NOK; }
				memcpy(&iDtcInfo, (uint8_t*)pData, sizeof(iDtcInfo));

				hConfig.iDTCStatus = (iDtcInfo | hConfig.iDTCStatus);

				uint32_t iDtcInfoAddress = Cluster_Controller_Hal_ConfigGetFlashAddress(VEHICLE_DTC_INFO);
#if !EEPROM
				Cluster_Controller_Hal_FlashErase(iDtcInfoAddress);
#endif
				iDtcBuf[0] = hConfig.iDTCStatus;

				iRval = Cluster_Controller_Hal_FlashWriteData(&iDtcBuf[0],
																sizeof(iDtcBuf),
																iDtcInfoAddress);
				iIsvalid = false;
			}
			break;
			default:
				iIsvalid = false;
				break;
		}

		if(iIsvalid)
		{
			uint8_t sBuf[sizeof(sDeviceInfo_t)] = {0};
			uint32_t iProductInfoAddr = Cluster_Controller_Hal_ConfigGetFlashAddress(VEHICLE_SPEC_INFO_MEMSEC);
#if !EEPROM
			Cluster_Controller_Hal_FlashErase(iProductInfoAddr);
#endif
			memcpy(sBuf,(uint8_t*)&(hConfig.sProductInfo),sizeof(sDeviceInfo_t));
			uint32_t iSize = sizeof(sDeviceInfo_t);
			iRval = Cluster_Controller_Hal_FlashWriteData(&sBuf[0],
					iSize ,
					iProductInfoAddr);
		}
		xSemaphoreGive(hConfig.pSysSema);
		return iRval;
	}
	else
	{
		return BCU_NOK;
	}
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: Cluster_Controller_Manager_SystemInfo_GetVehicleSpecInfo *
 * Params	        :	void		       									   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_GetVehicleSpecInfo(sDeviceInfo_t * pData)
{
	int32_t iRval = BCU_NOK;
	if(pData == NULL) { return BCU_NOK; }
	if((hConfig.iIsInitialised != 0) && (hConfig.iReadFlag == 1))
	{
		memcpy(pData,&(hConfig.sProductInfo),sizeof(sDeviceInfo_t));
		iRval = BCU_OK;
	}
	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	Cluster_Controller_Manager_SystemInfo_GetDTCInfo	   *
 * Params	        :	void		       									   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_GetDTCInfo(uint8_t * pDtcInfo)
{
	int32_t iRval = BCU_NOK;
	if(pDtcInfo == NULL) { return BCU_NOK; }
	if((hConfig.iIsInitialised != 0) && (hConfig.iReadFlag == 1))
	{
		*pDtcInfo = hConfig.iDTCStatus;
		iRval = BCU_OK;
	}
	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	SysInfo_ModeHandler						        	   *
 * Params	        :	void		       									   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
static void SysInfo_ModeHandler(void *arg)
{
	int32_t iRval = BCU_NOK;

	sSysInfo_t * pHan       = (sSysInfo_t *)(arg);

	TickType_t iDelay      = pdMS_TO_TICKS(2000);

	char sBuf[MSG_QUEUE_BUFFER_SIZE];

	memset(&sBuf[0],0, sizeof(sBuf));

	while(1)
	{
		xQueueReceive(pHan->qRxMsg,(char*)&sBuf[0],iDelay);

		if(pHan->iReadFlag == 0)
		{
			iRval = SystemInfo_GetVehicleSpecInfo(pHan);

			if(iRval == BCU_OK)
			{
				iRval = SystemInfo_GetDTCInfo(pHan);
				if(iRval != BCU_OK)
				{
					PRINTF("\r\nError: SystemInfo_GetDTCInfo\r\n");
				}

				iRval = SystemInfo_GetChargeStatus(pHan);
				if(iRval == BCU_OK)
				{
					pHan->iReadFlag = 1;
					iDelay = portMAX_DELAY;
				}
			}
		}

		if(iRval == BCU_NOK)
		{
			iDelay = pdMS_TO_TICKS(1000);
		}
	}
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	Cluster_Controller_GetDTCInfo							   *
 * Params	        :	void		       									   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
static int32_t SystemInfo_GetDTCInfo(sSysInfo_t * pHan)
{
	if(xSemaphoreTake(pHan->pSysSema, SYSINFO_SEMA_TIMEOUT) == pdTRUE)
	{
		int32_t iRval = BCU_NOK;
		uint8_t sBuf = 0;

		uint32_t iSize = sizeof(sBuf);

		uint32_t iDtcInfoAddress = Cluster_Controller_Hal_ConfigGetFlashAddress(VEHICLE_DTC_INFO);

		iRval = Cluster_Controller_Hal_FlashReadData(&sBuf,
				iSize ,
				iDtcInfoAddress);

		if(iRval == BCU_OK)
		{
			if(sBuf != 0xFF)
			{
				pHan->iDTCStatus = sBuf;
			}
			else
			{
				pHan->iDTCStatus = 0;
			}
		}
		xSemaphoreGive(pHan->pSysSema);
		return iRval;
	}
	else
	{
		return BCU_NOK;
	}
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	SystemInfo_GetVehicleSpecInfo							   *
 * Params	        :	void		       									   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
static int32_t SystemInfo_GetVehicleSpecInfo(sSysInfo_t * pHan)
{
	if(xSemaphoreTake(pHan->pSysSema, SYSINFO_SEMA_TIMEOUT) == pdTRUE)
	{
		int32_t iRval = BCU_NOK;
		uint8_t sBuf[sizeof(sDeviceInfo_t)] = {0};

		uint32_t iSize = sizeof(sDeviceInfo_t);

		uint32_t iVehicleInfoAddr = Cluster_Controller_Hal_ConfigGetFlashAddress(VEHICLE_SPEC_INFO_MEMSEC);

		iRval = Cluster_Controller_Hal_FlashReadData(&sBuf[0],
				iSize ,
				iVehicleInfoAddr);

		if(iRval == BCU_OK)
		{
			if((sBuf[0] == 0xFF) && (sBuf[1] == 0xFF)
					&& (sBuf[2] == 0xFF) && (sBuf[3] == 0xFF))
			{
				PRINTF("\r\nThe Device Info is not Set\r\n");
			}
			else
			{
				memcpy((char *)(&(pHan->sProductInfo)),(char*)(&sBuf[0]),sizeof(sDeviceInfo_t));
			}
		}
		xSemaphoreGive(pHan->pSysSema);
		return (iRval);
	}
	else
	{
		return BCU_NOK;
	}
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	SystemInfo_GetClusterData							   *
 * Params	        :	void		       									   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:	In this function,Read the data to secondary flash(Nvm) *
 *-----------------------------------------------------------------------------*/
static int32_t SystemInfo_GetClusterData(sSysInfo_t *pHan)
{
    int32_t iRval = BCU_NOK;

    memset(&(pHan->sInfoCache), 0, sizeof(sClusterInfo_t));

    bool bMemSec0Cur = SystemInfo_ReadClusterData(&pHan->sMemCache[0], CLUSTER_INFO_MEMSEC0);

    bool bMemSec1Cur = SystemInfo_ReadClusterData(&pHan->sMemCache[1], CLUSTER_INFO_MEMSEC1);

    SystemInfo_HandleCorruptSectors(pHan, bMemSec0Cur, bMemSec1Cur);

	sClusterInfo_t  *pSelectedCache = (pHan->sMemCache[0].iOdoVal >= pHan->sMemCache[1].iOdoVal) ?
    		                          &pHan->sMemCache[0] : &pHan->sMemCache[1];

	memcpy(&(pHan->sInfoCache), pSelectedCache, sizeof(sClusterInfo_t));

    iRval = BCU_OK;
    return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	SystemInfo_UpdateClusterData						   *
 * Params	        :	sClusterInfo_t* pData, int32_t iParam		  		   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:	In this function,Write the data to secondary flash(Nvm)*
 *-----------------------------------------------------------------------------*/
static int32_t SystemInfo_UpdateClusterData(sSysInfo_t * pHan,
											sClusterInfo_t* pData,
		                                    uint32_t iParam,
											uint32_t iSectorAddr)
{
	if (xSemaphoreTake(pHan->pSysSema, SYSINFO_SEMA_TIMEOUT) == pdTRUE)
	{
		int32_t iRval = BCU_NOK;
		bool iIsvalid = false;
		sClusterInfo_t     sInfo = {0};

		switch(iParam)
		{
			case eSpeedInfo:
			{
				if((pData->iOdoVal > pHan->sInfoCache.iOdoVal) && (pData->iOdoVal != 0xFFFFFFFF) && (pData->iOdoVal > 0))
				{
					pHan->sInfoCache.iOdoVal = pData->iOdoVal;
					iIsvalid = true;
				}

				if((pData->iCurTripA > pHan->sInfoCache.iCurTripA) && (pData->iCurTripA != 0xFFFFFFFF) && (pData->iCurTripA > 0))
				{
					pHan->sInfoCache.iCurTripA = pData->iCurTripA;
					iIsvalid = true;
				}

				if((pData->iCurTripB > pHan->sInfoCache.iCurTripB) && (pData->iCurTripB != 0xFFFFFFFF) && (pData->iCurTripB > 0))
				{
					pHan->sInfoCache.iCurTripB = pData->iCurTripB;
					iIsvalid = true;
				}

				if(iIsvalid)
				{
					iRval = SystemInfo_FlashWriteData(pHan,iSectorAddr,&pHan->sInfoCache);
					if(pHan->iCurSector == 0)
					{
						memcpy(&(pHan->sMemCache[0]), &(pHan->sInfoCache), sizeof(sClusterInfo_t));
					}
					else
					{
						memcpy(&(pHan->sMemCache[1]), &(pHan->sInfoCache), sizeof(sClusterInfo_t));
					}
				}
				else
				{
					/* No change in odo/trip � no write needed, not an error */
					iRval = BCU_OK;
				}
			}
			break;
			case eResetInfo:
			{
				uint32_t iAddress0 = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC0);
				uint32_t iAddress1 = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC1);
				iRval = BCU_OK;
				sInfo.iOdoVal = 0;
				sInfo.iCurTripA = 0;
				sInfo.iCurTripB = 0;
				if((pHan->sMemCache[0].iOdoVal != 0) || (pHan->sMemCache[0].iCurTripA != 0) || (pHan->sMemCache[0].iCurTripB != 0))
				{
					iRval = SystemInfo_FlashWriteData(pHan,iAddress0,&sInfo);
					pHan->sMemCache[0].iOdoVal = 0;
					pHan->sMemCache[0].iCurTripA = 0;
					pHan->sMemCache[0].iCurTripB = 0;
				}

				if((pHan->sMemCache[1].iOdoVal != 0)|| (pHan->sMemCache[1].iCurTripA != 0) || (pHan->sMemCache[1].iCurTripB != 0))
				{
					iRval = SystemInfo_FlashWriteData(pHan,iAddress1,&sInfo);
					pHan->sMemCache[1].iOdoVal = 0;
					pHan->sMemCache[1].iCurTripA = 0;
					pHan->sMemCache[1].iCurTripB = 0;
				}

				memset(&(pHan->sInfoCache), 0,sizeof(sClusterInfo_t));
			}
			break;
			case eSetOdo:
			{
				uint32_t iAddress0 = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC0);
				uint32_t iAddress1 = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC1);
				iRval = BCU_OK;
				sInfo.iOdoVal  = pData->iOdoVal;
				sInfo.iCurTripA = pData->iCurTripA;
				sInfo.iCurTripB = pData->iCurTripB;

				if((pData->iOdoVal != 0xFFFFFFFF) && (pHan->sInfoCache.iOdoVal != pData->iOdoVal))
				{

					if((pHan->sMemCache[0].iOdoVal != pData->iOdoVal))
					{

						iRval = SystemInfo_FlashWriteData(pHan,iAddress0,&sInfo);
						pHan->sMemCache[0].iOdoVal =pData->iOdoVal;
					}

					if((pHan->sMemCache[1].iOdoVal  != pData->iOdoVal))
					{

						iRval = SystemInfo_FlashWriteData(pHan,iAddress1,&sInfo);
						pHan->sMemCache[1].iOdoVal = pData->iOdoVal;
					}

					memcpy(&(pHan->sInfoCache), &sInfo, sizeof(sClusterInfo_t));
				}
			}
			break;

			case eResetTripA:
			{
				uint32_t iAddress0 = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC0);
				uint32_t iAddress1 = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC1);
				iRval = BCU_OK;
				sInfo.iOdoVal = pData->iOdoVal;
				sInfo.iCurTripB = pData->iCurTripB;
				sInfo.iCurTripA = 0;

				if((pHan->sMemCache[0].iCurTripA != 0))
				{
					iRval = SystemInfo_FlashWriteData(pHan,iAddress0,&sInfo);
					pHan->sMemCache[0].iCurTripA = 0;
					pHan->sMemCache[0].iOdoVal = sInfo.iOdoVal;
					pHan->sMemCache[0].iCurTripB = sInfo.iCurTripB;
				}
				if((pHan->sMemCache[1].iCurTripA != 0))
				{

					iRval = SystemInfo_FlashWriteData(pHan,iAddress1,&sInfo);
					pHan->sMemCache[1].iCurTripA = 0;
					pHan->sMemCache[1].iOdoVal = sInfo.iOdoVal;
					pHan->sMemCache[1].iCurTripB = sInfo.iCurTripB;
				}

				memcpy(&(pHan->sInfoCache), &sInfo, sizeof(sClusterInfo_t));
			}
			break;

			case eResetTripB:
			{
				uint32_t iAddress0 = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC0);
				uint32_t iAddress1 = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC1);
				iRval = BCU_OK;
				sInfo.iOdoVal = pData->iOdoVal;
				sInfo.iCurTripA = pData->iCurTripA;
				sInfo.iCurTripB = 0;

				if((pHan->sMemCache[0].iCurTripB != 0))
				{
					iRval = SystemInfo_FlashWriteData(pHan,iAddress0,&sInfo);
					pHan->sMemCache[0].iCurTripB = 0;
					pHan->sMemCache[0].iOdoVal = sInfo.iOdoVal;
					pHan->sMemCache[0].iCurTripA = sInfo.iCurTripA;
				}
				if((pHan->sMemCache[1].iCurTripB != 0))
				{

					iRval = SystemInfo_FlashWriteData(pHan,iAddress1,&sInfo);
					pHan->sMemCache[1].iCurTripB = 0;
					pHan->sMemCache[1].iOdoVal = sInfo.iOdoVal;
					pHan->sMemCache[1].iCurTripA = sInfo.iCurTripA;
				}

				memcpy(&(pHan->sInfoCache), &sInfo, sizeof(sClusterInfo_t));
			}
			break;
			default:
			break;
		}
		xSemaphoreGive(pHan->pSysSema);
		return (iRval);
	}
	else
	{
		return BCU_NOK;
	}
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	SystemInfo_FlashWriteData   						   *
 * Params	        :	                                        	  		   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
static int32_t SystemInfo_FlashWriteData(sSysInfo_t *pHan, uint32_t iSectorAddr,sClusterInfo_t *pData)
{
	int32_t iRval = BCU_NOK;

	uint8_t sBuf[sizeof(sClusterInfo_t)] = {0};

	(void)(pHan);
#if !EEPROM
	Cluster_Controller_Hal_FlashErase(iSectorAddr);
#endif
	uint32_t iSize = sizeof(sClusterInfo_t);

	memcpy(sBuf,(uint8_t*)(pData),iSize);

	iRval = Cluster_Controller_Hal_FlashWriteData(&sBuf[0],iSize ,iSectorAddr);

	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	SystemInfo_ReadClusterData   						   *
 * Params	        :	                                        	  		   *
 * Return value		:	On success return BCU_OK else return BCU_NOK           *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
static int32_t SystemInfo_ReadClusterData(sClusterInfo_t * pCache, uint32_t iSector)
{
	int32_t iRval = BCU_NOK;

	uint8_t sBuf[sizeof(sClusterInfo_t)] = {0};

	uint32_t iSectorAddr = Cluster_Controller_Hal_ConfigGetFlashAddress(iSector);

	iRval = Cluster_Controller_Hal_FlashReadData(sBuf, sizeof(sClusterInfo_t), iSectorAddr);

	if (iRval == BCU_OK)
	{
		memcpy(pCache, sBuf, sizeof(sClusterInfo_t));

		PRINTF("\r\n\033[33mIn SysInfo sector %d Cached Data :OdO:\033[0m\033[32m[ %d] \033[33m, tripA:\033[0m\033[32m[ %d]\033[0m, tripB:\033[0m\033[32m[ %d]\033[0m\r\n",
				iSector, pCache->iOdoVal, pCache->iCurTripA, pCache->iCurTripB);

		iRval =  ((pCache->iOdoVal == 0xFFFFFFFF) && ((pCache->iCurTripA == 0xFFFFFFFF) || (pCache->iCurTripB == 0xFFFFFFFF))) ? 1 : 0;
	}
	else
	{
		PRINTF("\r\nError: Failed to read sector %d \r\n", iSector);
		iRval =  BCU_NOK;
	}

	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	SystemInfo_HandleCorruptSectors 					   *
 * Params	        :	                                        	  		   *
 * Return value		:	                                                       *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
static void SystemInfo_HandleCorruptSectors(sSysInfo_t *pHan, int iMemSec0, int iMemSec1)
{
    if((iMemSec0) && (iMemSec1))
    {
        PRINTF("\r\nIn SysInfo: The Device is New or NVM is Corrupted\r\n");
        SystemInfo_UpdateClusterData(pHan,&pHan->sInfoCache,eResetInfo,0);
        memset(&pHan->sMemCache[0], 0, sizeof(sClusterInfo_t));
        memset(&pHan->sMemCache[1], 0, sizeof(sClusterInfo_t));
        pHan->iCorruptedSector = CORRUPTED_SECTORALL;
    }
    else if(iMemSec0)
    {
        /* Sector 0 corrupted: restore from sector 1, then continue normally */
        PRINTF("\r\nIn SysInfo: NVM Sector0 Corrupted - restoring from Sector1\r\n");
        uint32_t iSectorAddr = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC0);
        int32_t iRval = SystemInfo_UpdateClusterData(pHan, &pHan->sMemCache[1], eSpeedInfo, iSectorAddr);
        if(iRval == BCU_OK)
        {
            /* Recovery succeeded: both sectors now hold the same data */
            memcpy(&pHan->sMemCache[0], &pHan->sMemCache[1], sizeof(sClusterInfo_t));
            pHan->iCurSector       = 1;  /* next write alternates to sector 1 */
            pHan->iCorruptedSector = 0;  /* sector 0 is healthy again */
        }
        else
        {
            /* Recovery failed: discard sector 0, keep writing to healthy sector 1 */
            PRINTF("\r\nIn SysInfo: Sector0 recovery failed\r\n");
            memset(&pHan->sMemCache[0], 0, sizeof(sClusterInfo_t));
            pHan->iCurSector       = 1;
            pHan->iCorruptedSector = CORRUPTED_SECTOR0;
        }
    }
    else if(iMemSec1)
    {
        /* Sector 1 corrupted: restore from sector 0, then continue normally */
        PRINTF("\r\nIn SysInfo: NVM Sector1 Corrupted - restoring from Sector0\r\n");
        uint32_t iSectorAddr = Cluster_Controller_Hal_ConfigGetFlashAddress(CLUSTER_INFO_MEMSEC1);
        int32_t iRval = SystemInfo_UpdateClusterData(pHan, &pHan->sMemCache[0], eSpeedInfo, iSectorAddr);
        if(iRval == BCU_OK)
        {
            /* Recovery succeeded: both sectors now hold the same data */
            memcpy(&pHan->sMemCache[1], &pHan->sMemCache[0], sizeof(sClusterInfo_t));
            pHan->iCurSector       = 0;  /* next write alternates to sector 0 */
            pHan->iCorruptedSector = 0;  /* sector 1 is healthy again */
        }
        else
        {
            /* Recovery failed: discard sector 1, keep writing to healthy sector 0 */
            PRINTF("\r\nIn SysInfo: Sector1 recovery failed\r\n");
            memset(&pHan->sMemCache[1], 0, sizeof(sClusterInfo_t));
            pHan->iCurSector       = 0;
            pHan->iCorruptedSector = CORRUPTED_SECTOR1;
        }
    }
}
/*-----------------------------------------------------------------------------*
 * Function	   	 	: 	SystemInfo_GetChargeStatus 					   *
 * Params	        :	                                        	  		   *
 * Return value		:	                                                       *
 * Description  	:														   *
 *-----------------------------------------------------------------------------*/
static int32_t SystemInfo_GetChargeStatus(sSysInfo_t * pHan)
{
	int32_t iRval = BCU_NOK;

	uint8_t sBuf[sizeof(sChargeAlert_t)] = {0};

	if (xSemaphoreTake(pHan->pSysSema, SYSINFO_SEMA_TIMEOUT) == pdTRUE)
	{
		uint32_t iSectorAddr = Cluster_Controller_Hal_ConfigGetFlashAddress(VEHICLE_CHARGESTATE_INFO);
		iRval = Cluster_Controller_Hal_FlashReadData(&sBuf[0], sizeof(sBuf),iSectorAddr);
		if (iRval == BCU_OK)
		{
		     memcpy(&(pHan->sChargeAlert), &sBuf[0], sizeof(sChargeAlert_t));
		}
		xSemaphoreGive(pHan->pSysSema);
	}

    return iRval;
}
