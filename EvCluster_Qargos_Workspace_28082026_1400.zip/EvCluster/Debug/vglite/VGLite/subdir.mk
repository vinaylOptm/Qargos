################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../vglite/VGLite/vg_lite.c \
../vglite/VGLite/vg_lite_flat.c \
../vglite/VGLite/vg_lite_image.c \
../vglite/VGLite/vg_lite_matrix.c \
../vglite/VGLite/vg_lite_path.c 

C_DEPS += \
./vglite/VGLite/vg_lite.d \
./vglite/VGLite/vg_lite_flat.d \
./vglite/VGLite/vg_lite_image.d \
./vglite/VGLite/vg_lite_matrix.d \
./vglite/VGLite/vg_lite_path.d 

OBJS += \
./vglite/VGLite/vg_lite.o \
./vglite/VGLite/vg_lite_flat.o \
./vglite/VGLite/vg_lite_image.o \
./vglite/VGLite/vg_lite_matrix.o \
./vglite/VGLite/vg_lite_path.o 


# Each subdirectory must supply rules for building sources it contributes
vglite/VGLite/%.o: ../vglite/VGLite/%.c vglite/VGLite/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCLUSTER_PANEL_WIDTH=800 -DCLUSTER_PANEL_HEIGHT=480 -DUDS_SERVICE_ENABLE=0 -DEEPROM=0 -DBLE_ENABLED=0 -DCLUSTER_HW_VERSION=2 -DCLUSTER_DISPLAY_INTERFACE=0 -DCLUSTER_DISPLAY=2 -DCLUSTER_NAVIGATION_SWITCH_ENABLE=1 -DCPU_MIMXRT1176AVM8A -DCPU_MIMXRT1176DVMAA_cm7 -DCPU_MIMXRT1176DVMAA -DCPU_MIMXRT1176AVM8A_cm7 -DSDK_OS_BAREMETAL -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSERIAL_PORT_TYPE_UART=1 -DXIP_BOOT_HEADER_DCD_ENABLE=1 -DXIP_BOOT_HEADER_XMCD_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -DSDK_OS_FREE_RTOS -D__USE_CMSIS -DDEBUG -DCPP_NO_HEAP -DFSL_RTOS_FREE_RTOS -D"PRINTF_ADVANCED_ENABLE =0" -D"PRINTF_FLOAT_ENABLE =0" -D"SCANF_ADVANCED_ENABLE =0" -DSCANF_FLOAT_ENABLE=0 -DSKIP_SYSCLK_INIT -DUSE_SDRAM -DSDK_I2C_BASED_COMPONENT_USED=1 -DENABLE_PWM_CONTROL=0 -DCLUSTER_KEYIGNITION_SUPPORTED=1 -DSDIO_ENABLED -DDATA_SECTION_IS_CACHEABLE=1 -DCUSTOM_VGLITE_MEMORY_CONFIG=0 -DVG_COMMAND_CALL=1 -DVG_TARGET_FAST_CLEAR=0 -DSDK_DEBUGCONSOLE_UART -DDEBUG_CONSOLE_RX_ENABLE=0 -DFSL_SDK_DRIVER_QUICK_ACCESS_ENABLE=1 -DCR_INTEGER_PRINTF -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\board" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\osa" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\controller\hmi\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\opensource\cjson" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\freertos\freertos-kernel\include" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\freertos\freertos-kernel\portable\GCC\ARM_CM4F" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\drivers" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\xip" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\device" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\CMSIS" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\serial_manager" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\uart" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\utilities" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\video" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\lists" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\startup" -I"C:\Qt\QtMCUs\2.5.0\include" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\qoi" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\minihdlc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\common" -I"C:\Qt\QtMCUs\2.5.0\src\3rdparty\nanopb" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\platform\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\platform\boards\nxp\mimxrt1170-evk-freertos\display" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\vglite\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\vglite\VGLite\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\vglite\VGLiteKernel" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\vglite\VGLiteKernel\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\config" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\controller\hal\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\cluster\controller\manager\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\EvCluster\component\gpio" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\GeneratedHmi\qargos_ui" -O0 -fno-common -g3 -Wall -Wextra -Wconversion -Wcast-align -Wcast-qual -Wdisabled-optimization -Wlogical-op -Wmissing-declarations -Wredundant-decls -Wshadow -Wsign-conversion -Wswitch-default -Wundef -Wfloat-equal -c -ffunction-sections -fdata-sections -ffreestanding -fno-builtin -imacros "D:\Cluster_Workspace\Grav_Blinq_Liger\Qargos\Qargos_SDK2.13\EvCluster_Qargos_Workspace_V1.2\New folder\EvCluster_Qargos_Workspace_17082026_1848\EvCluster\source\wifi_config.h" -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-vglite-2f-VGLite

clean-vglite-2f-VGLite:
	-$(RM) ./vglite/VGLite/vg_lite.d ./vglite/VGLite/vg_lite.o ./vglite/VGLite/vg_lite_flat.d ./vglite/VGLite/vg_lite_flat.o ./vglite/VGLite/vg_lite_image.d ./vglite/VGLite/vg_lite_image.o ./vglite/VGLite/vg_lite_matrix.d ./vglite/VGLite/vg_lite_matrix.o ./vglite/VGLite/vg_lite_path.d ./vglite/VGLite/vg_lite_path.o

.PHONY: clean-vglite-2f-VGLite

